---
name: research
description: Pesquisa e verifica fatos para documentários e True Crime no Auto Tube Studio.
---

# Apuração e pesquisa

1. Transforme o tema em perguntas verificáveis.
2. Priorize documentos oficiais, registros judiciais públicos, arquivos, estudos acadêmicos e fontes primárias. Use veículos jornalísticos reconhecidos para contexto e confirmação independente.
3. Confirme nomes, datas, locais, números e citações. Para fatos centrais, procure confirmação independente adicional.
4. Registre para cada fonte: título, organização/autoria, URL, data de publicação e data de acesso; anote qual afirmação ela sustenta.
5. Diferencie fato confirmado, alegação, hipótese, versão de testemunha e ponto contestado.
6. Em True Crime, use “suspeito”, “investigado”, “acusado”, “réu” ou “condenado” conforme o estágio processual documentado. Não chame pessoa de criminosa sem condenação aplicável.
7. Não publique endereço residencial, telefone, dados de crianças ou detalhes íntimos sem necessidade editorial clara.
8. Não invente detalhes para preencher lacunas. Indique explicitamente o que não foi possível confirmar.
9. Imagens geradas por IA são ilustrações/reconstruções, não provas nem fotografias documentais.
