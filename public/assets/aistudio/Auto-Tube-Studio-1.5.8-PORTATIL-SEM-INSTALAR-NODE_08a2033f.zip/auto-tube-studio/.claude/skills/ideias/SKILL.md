---
name: ideias
description: Sugere pautas e formatos para novos vídeos do Auto Tube Studio.
---

# Ideias de vídeos

1. Verifique projetos já existentes com `node ats.mjs listar` para evitar repetição.
2. Considere os formatos Vidas e Cotidiano — Ficção, Vidas e Cotidiano — Documentário e True Crime.
3. Para temas factuais, avalie se há fontes públicas suficientes antes de sugerir.
4. Apresente 8 ideias com tema, formato, duração, gancho e justificativa editorial.
5. Misture temas atemporais e atuais. Não sugerir acusações não verificadas nem sensacionalismo.
