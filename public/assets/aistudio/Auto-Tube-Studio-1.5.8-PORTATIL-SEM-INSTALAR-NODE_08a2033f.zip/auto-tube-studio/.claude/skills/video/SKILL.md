---
name: video
description: Produz vídeos no Auto Tube Studio do tema ao roteiro, imagens Gemini, narração importada e MP4 final.
---

# Produção completa de vídeo — Auto Tube Studio

## 1. Preparar projeto
- Execute `node ats.mjs diagnostico` e `node ats.mjs listar`.
- Crie o projeto com `node ats.mjs novo --tipo=vidas-ficcao|vidas-doc|true-crime --titulo="..." --duracao=480`.
- Registre o ID retornado e consulte `node ats.mjs ver <id>`.
- Não solicite confirmação para etapas normais; a autorização de desenvolvimento e continuidade já foi concedida.

## 2. Pesquisa e fontes
- Para Vidas e Cotidiano — Ficção, invente a história, sem atribuir crimes ou fatos falsos a pessoas reais.
- Para documentários e True Crime, use pesquisa web ou fontes públicas disponíveis no ambiente. Priorize documentos oficiais, registros judiciais, arquivos, estudos e fontes primárias; use imprensa confiável para contexto e confirmação independente.
- Registre título, organização/autoria, URL e a afirmação sustentada em `sources` no JSON do roteiro. Não invente fontes ou URLs.
- Diferencie fato confirmado, alegação, hipótese, depoimento, suspeita, investigação, acusação, julgamento, condenação e ponto contestado.
- Em True Crime, preserve a dignidade das vítimas e não publique dados privados desnecessários.

## 3. Escrever roteiro por cenas
- Vídeo longo: gancho inicial forte, contexto, capítulos e progressão narrativa.
- Vídeo curto: gancho imediato, cenas curtas, uma virada e fechamento.
- Cada cena deve conter `id`, `title`, `narration`, `visualPrompt` e `durationSeconds`.
- Cada prompt visual descreve ambiente, personagem, roupas, época, iluminação, enquadramento e continuidade. Imagens sempre horizontais 16:9.
- Nos formatos factuais, as imagens Gemini são reconstruções ilustrativas, nunca provas ou fotos documentais autênticas.
- Estrutura JSON:
```json
{
  "logline": "Promessa central do vídeo",
  "chapters": [{"title":"Abertura","startScene":1}],
  "sources": [{"title":"Fonte consultada","publisher":"Instituição","url":"https://...","supports":"Afirmação sustentada"}],
  "scenes": [{"id":"scene-001","title":"Abertura","narration":"Texto falado.","visualPrompt":"Cena cinematográfica 16:9 sem texto embutido.","durationSeconds":8}]
}
```
- Salve em `projects/<id>/roteiro.json` e execute `node ats.mjs salvar-roteiro <id> projects/<id>/roteiro.json`.

## 4. Gerar imagens
- Execute `node ats.mjs gerar-todas <id>` para gerar as imagens que faltam em sequência.
- Ou gere individualmente: `node ats.mjs gerar-imagem <id> scene-001`.
- Revise as imagens e a continuidade. Refaça cenas incoerentes ajustando o prompt.

## 5. Narração e montagem
- O painel aceita áudio de narração em `Criar projeto > Enviar áudio`.
- Ajuste a duração de cada cena para acompanhar a narração; a legenda é sincronizada por cena, não por palavra.
- Exporte SRT com `node ats.mjs baixar-srt <id> legendas.srt`.
- Renderize com `node ats.mjs renderizar <id>` quando o FFmpeg estiver instalado e disponível no PATH.
- O MP4 é 1920×1080, com movimento Ken Burns, legendas, marca d'água opcional e rótulo discreto `ILUSTRAÇÃO` nos formatos factuais.

## 6. Música de fundo automática
- Antes da montagem final, siga integralmente a seção “Seleção automática de música” do `CLAUDE.md`.
- Procure uma faixa local autorizada em `data/music-library/` ou nos projetos existentes. A Biblioteca de Áudio do YouTube é a fonte prioritária, mas o Claude Code não deve presumir acesso direto para baixar faixas; use somente arquivos que o usuário já tenha obtido legitimamente.
- Selecione por gênero, clima e ritmo do roteiro; prefira instrumentais discretas quando houver narração.
- Só utilize faixas com licença documentada que permita uso comercial e monetização no YouTube, incluindo crédito quando exigido.
- Copie a faixa e o comprovante para o projeto atual, ative ducking e volume discreto e registre a decisão em `music-selection.json`.
- Se não houver faixa aprovada, renderize sem música e informe isso. Nunca substitua por uma faixa desconhecida.

## 7. Entrega e honestidade
- Confirme que o MP4 existe e use `ffprobe` para validar duração, resolução e faixa de áudio.
- Informe o caminho do vídeo, roteiro, fontes e legendas.
- Não afirme que há narração sintetizada, sincronização palavra por palavra, thumbnail ou publicação automática: esses recursos não fazem parte da versão 1.0 atual.
