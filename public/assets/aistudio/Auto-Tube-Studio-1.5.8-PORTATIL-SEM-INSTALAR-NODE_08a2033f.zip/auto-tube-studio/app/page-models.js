window.ATS_PAGE_MODELS = [
  {
    "id": "historia",
    "icon": "🏛️",
    "name": "História",
    "description": "Pergaminho, mapas antigos, gravuras e paleta sépia.",
    "bg": "#ead9b5",
    "accent": "#8d542d",
    "style": "serif",
    "group": "Galeria tradicional"
  },
  {
    "id": "curiosidades",
    "icon": "💡",
    "name": "Curiosidades",
    "description": "Pop de figurinha, retícula amarela, emojis e cartões vibrantes.",
    "bg": "#ffd83d",
    "accent": "#ff477e",
    "style": "rounded",
    "group": "Galeria tradicional"
  },
  {
    "id": "como-funciona-3d",
    "icon": "⚙️",
    "name": "Como funciona (3D)",
    "description": "Planta técnica azul, grade e ilustrações tridimensionais.",
    "bg": "#0b3a6e",
    "accent": "#ffd166",
    "style": "technical",
    "group": "Galeria tradicional"
  },
  {
    "id": "corpo-humano-saude",
    "icon": "🫀",
    "name": "Corpo humano e saúde",
    "description": "Visual clínico claro, anatomia 3D e diagramas explicativos.",
    "bg": "#eaf5f4",
    "accent": "#168f88",
    "style": "clean",
    "group": "Galeria tradicional"
  },
  {
    "id": "financas",
    "icon": "💰",
    "name": "Finanças",
    "description": "Terminal financeiro escuro, números e gráficos de mercado.",
    "bg": "#07130f",
    "accent": "#00e59b",
    "style": "mono",
    "group": "Galeria tradicional"
  },
  {
    "id": "noticias-explicadas",
    "icon": "📰",
    "name": "Notícias explicadas",
    "description": "Telejornal editorial, manchetes curtas e faixas de notícia.",
    "bg": "#092b54",
    "accent": "#ff4c5e",
    "style": "news",
    "group": "Galeria tradicional"
  },
  {
    "id": "misterios",
    "icon": "🕵️",
    "name": "Mistérios",
    "description": "Arquivo confidencial, carimbos, fotografias e documentos.",
    "bg": "#0c0c14",
    "accent": "#f34a4a",
    "style": "typewriter",
    "group": "Galeria tradicional"
  },
  {
    "id": "ciencia-espaco",
    "icon": "🚀",
    "name": "Ciência e espaço",
    "description": "Cosmos, órbitas, estrelas e tipografia futurista.",
    "bg": "#080d28",
    "accent": "#70c8ff",
    "style": "space",
    "group": "Galeria tradicional"
  },
  {
    "id": "anuncio-interface",
    "icon": "🧩",
    "name": "Anúncio de interface",
    "description": "Telas de produto, componentes e chamadas comerciais discretas.",
    "bg": "#171327",
    "accent": "#9b75ff",
    "style": "ui",
    "group": "Galeria tradicional"
  },
  {
    "id": "bichos-3d",
    "icon": "🐾",
    "name": "Bichos em 3D",
    "description": "Animais em 3D no próprio ambiente, com cenas expressivas.",
    "bg": "#132018",
    "accent": "#8ddc73",
    "style": "rounded",
    "group": "Galeria tradicional"
  },
  {
    "id": "motivacao-habitos",
    "icon": "🔥",
    "name": "Motivação e hábitos",
    "description": "Tipografia forte, frases curtas e contraste cinematográfico.",
    "bg": "#171717",
    "accent": "#ff5b32",
    "style": "bold",
    "group": "Galeria tradicional"
  },
  {
    "id": "tecnologia",
    "icon": "💻",
    "name": "Tecnologia",
    "description": "Placa de circuito, linhas digitais e ciano luminoso.",
    "bg": "#07151b",
    "accent": "#19d9e8",
    "style": "tech",
    "group": "Galeria tradicional"
  },
  {
    "id": "inteligencia-artificial",
    "icon": "🤖",
    "name": "Inteligência artificial",
    "description": "Janela de conversa, interface de IA e elementos digitais.",
    "bg": "#111020",
    "accent": "#ad8cff",
    "style": "ui",
    "group": "Galeria tradicional"
  },
  {
    "id": "renda-extra-negocios",
    "icon": "📈",
    "name": "Renda extra e negócios",
    "description": "Planilha limpa, indicadores e números destacados.",
    "bg": "#eff4ed",
    "accent": "#20a85a",
    "style": "clean",
    "group": "Galeria tradicional"
  },
  {
    "id": "imoveis",
    "icon": "🏠",
    "name": "Imóveis",
    "description": "Plantas arquitetônicas, comparações e visual de projeto.",
    "bg": "#f3eee3",
    "accent": "#d59b54",
    "style": "serif",
    "group": "Galeria tradicional"
  },
  {
    "id": "terror-lendas-urbanas",
    "icon": "👻",
    "name": "Terror e lendas urbanas",
    "description": "Fita VHS, ruído analógico, sombras e suspense.",
    "bg": "#09090d",
    "accent": "#e63d5a",
    "style": "horror",
    "group": "Galeria tradicional"
  },
  {
    "id": "mitologia-folclore",
    "icon": "🐉",
    "name": "Mitologia e folclore",
    "description": "Moldura dourada, ornamentos e ilustrações lendárias.",
    "bg": "#17100b",
    "accent": "#d7a64b",
    "style": "serif",
    "group": "Galeria tradicional"
  },
  {
    "id": "explicado-1-minuto",
    "icon": "⏱️",
    "name": "Explicado em 1 minuto",
    "description": "Caderno, marca-texto e explicações rápidas em etapas.",
    "bg": "#f7f2e7",
    "accent": "#e84b40",
    "style": "hand",
    "group": "Galeria tradicional"
  },
  {
    "id": "games",
    "icon": "🎮",
    "name": "Games",
    "description": "Pixel art, HUD e estética retrô de videogame.",
    "bg": "#17172c",
    "accent": "#63e36f",
    "style": "pixel",
    "group": "Galeria tradicional"
  },
  {
    "id": "quiz-desafios",
    "icon": "❓",
    "name": "Quiz e desafios",
    "description": "Programa de auditório, alternativas e placar.",
    "bg": "#20104b",
    "accent": "#ffda4b",
    "style": "show",
    "group": "Galeria tradicional"
  },
  {
    "id": "top5-rankings",
    "icon": "🏆",
    "name": "Top 5 e rankings",
    "description": "Pódio, posições numeradas e medalhas.",
    "bg": "#101014",
    "accent": "#ffb62e",
    "style": "bold",
    "group": "Galeria tradicional"
  },
  {
    "id": "historias-fundo-satisfatorio",
    "icon": "🌀",
    "name": "Histórias com fundo satisfatório",
    "description": "Animação hipnótica abstrata e narração em primeiro plano.",
    "bg": "#10101c",
    "accent": "#a58cff",
    "style": "minimal",
    "group": "Galeria tradicional"
  },
  {
    "id": "mapas-geografia",
    "icon": "🗺️",
    "name": "Mapas e geografia",
    "description": "Cartografia, rotas, mapas e destaques territoriais.",
    "bg": "#0c2634",
    "accent": "#42c5e5",
    "style": "map",
    "group": "Galeria tradicional"
  },
  {
    "id": "autoridade-vendas",
    "icon": "🎯",
    "name": "Autoridade e vendas",
    "description": "Editorial minimalista, tipografia e música, sem excesso visual.",
    "bg": "#f4f0e7",
    "accent": "#292929",
    "style": "editorial",
    "group": "Galeria tradicional"
  },
  {
    "id": "vidas-ficcao",
    "icon": "🎬",
    "name": "Vidas e Cotidiano — Ficção",
    "description": "Narrativa cinematográfica ficcional, personagens consistentes e imagens em tela cheia.",
    "bg": "#17151a",
    "accent": "#e8b96c",
    "style": "cinema",
    "group": "Novos formatos"
  },
  {
    "id": "vidas-doc",
    "icon": "🌍",
    "name": "Vidas e Cotidiano — Documentário",
    "description": "Documentário de culturas, profissões e lugares, com fatos e fontes.",
    "bg": "#101c20",
    "accent": "#7dc9b3",
    "style": "documentary",
    "group": "Novos formatos"
  },
  {
    "id": "true-crime",
    "icon": "🔎",
    "name": "True Crime",
    "description": "Investigação documental, cronologia, fontes e cuidado com vítimas e suspeitos.",
    "bg": "#121216",
    "accent": "#c94d55",
    "style": "crime",
    "group": "Novos formatos"
  }
];
