const $=s=>document.querySelector(s),$$=s=>document.querySelectorAll(s);
let activeProject=null;
function tab(name){$$('.tab').forEach(x=>x.classList.toggle('show',x.id===name));$$('.nav').forEach(x=>x.classList.toggle('active',x.dataset.tab===name));$('#pageTitle').textContent=({home:'Início',lessons:'Aulas',start:'Começar',license:'Licença',voice:'Voz da narração',brand:'Marca',pagetypes:'Tipo de página',test:'Vídeo teste',create:'Novo vídeo',series:'Série de vídeos',projects:'Meus vídeos',music:'Música',settings:'Ajustes'})[name]||'Auto Tube Studio';
if(name==='start')runDiagnostics();if(name==='brand'){syncBrandFields();loadBrandWatermarkPreview();}if(name==='series'){populateSeriesProjects();if(!seriesEpisodeDrafts.length)addSeriesEpisode();}if(name==='projects')loadAllProjects();if(name==='test')updateTestProjectStatus();}
$$('.nav').forEach(b=>b.addEventListener('click',()=>tab(b.dataset.tab)));$$('[data-go]').forEach(b=>b.addEventListener('click',()=>tab(b.dataset.go)));
function escapeHtml(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
async function request(url,options={}){const r=await fetch(url,options);const d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||`Erro HTTP ${r.status}`);return d;}

// Páginas adicionais do fluxo de produção
async function runDiagnostics(){
 const host=$('#diagnosticsList'),banner=$('#readinessBanner');if(!host)return;
 host.innerHTML='<p class="mutedline">Verificando componentes...</p>';
 const rows=[];
 try{
  const h=await request('/api/health');
  rows.push(['Servidor e Node.js',true,`Servidor ativo · Node ${h.node||'versão não informada'} · ${h.platform||'ambiente local'}`]);
  rows.push(['FFmpeg',!!h.ffmpeg,h.ffmpeg?`${h.ffmpegInfo?.version||'FFmpeg encontrado'} · renderização disponível.`:'FFmpeg 6.1.1 não encontrado. Execute INICIAR.bat para instalar automaticamente.']);
 }catch(e){rows.push(['Servidor local',false,e.message]);}
 try{const p=await Promise.race([request('/api/piper/status'),new Promise((_,reject)=>setTimeout(()=>reject(new Error('Verificação demorou. Confira manualmente na Central de narração.')),3500))]);rows.push(['Piper',!!p.installed,p.installed?'Piper instalado.':'Piper não instalado; instale na Central de narração.']);}
 catch(e){rows.push(['Piper','info',e.message]);}
 try{const s=await request('/api/settings');rows.push(['Gemini',!!s.configured,s.configured?'Chave Gemini configurada.':'Configure a chave Gemini em Ajustes.']);rows.push(['ElevenLabs',!!s.elevenConfigured,s.elevenConfigured?'Chave ElevenLabs cadastrada.':'Opcional: configure ElevenLabs ou utilize Piper.']);}
 catch(e){rows.push(['Configurações',false,e.message]);}
 let webgl=false;try{const c=document.createElement('canvas');webgl=!!(c.getContext('webgl')||c.getContext('experimental-webgl'));}catch{}
 rows.push(['Navegador / WebGL',webgl,webgl?'WebGL disponível neste navegador.':'WebGL não detectado. Atualize o navegador ou driver gráfico.']);
 rows.push(['Claude Code','info','A integração é iniciada pelo atalho CLAUDE-CODE.bat; a autenticação deve ser conferida no terminal.']);
 rows.push(['Marca do canal','info','Confira o nome e o logotipo na seção Marca.']);
 host.innerHTML=rows.map(([n,ok,desc])=>`<article class="diagnosticrow"><span class="diagdot ${ok===true?'good':ok===false?'bad':'warn'}"></span><div><b>${escapeHtml(n)}</b><small>${escapeHtml(desc)}</small></div><span class="diagstate">${ok===true?'OK':ok===false?'Atenção':'Conferir'}</span></article>`).join('');
 const failed=rows.filter(x=>x[1]===false).length;banner.innerHTML=failed?`<b>${failed} item(ns) precisam de atenção</b><span>Consulte a lista abaixo. Itens opcionais, como ElevenLabs, não impedem usar Piper.</span>`:'<b>Verificação concluída</b><span>Os componentes essenciais detectados estão disponíveis. Confira também os itens informativos.</span>';
}
$('#checkAll')?.addEventListener('click',runDiagnostics);
function syncBrandFields(){if($('#brandChannel')){$('#brandChannel').value=$('#channelName').value||'';$('#brandWatermark').value=$('#watermark').value||'';}}
async function saveBrand(){
 const status=$('#brandStatus');status.textContent='Salvando identidade...';
 try{
  const payload={channelName:$('#brandChannel').value,watermark:$('#brandWatermark').value};
  const d=await request('/api/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
  $('#channelName').value=payload.channelName;$('#watermark').value=payload.watermark;status.textContent='Identidade visual salva nos ajustes locais.';
 }catch(e){status.textContent=e.message;}
}
$('#brandSave')?.addEventListener('click',saveBrand);
function showBrandWatermarkPreview(src){
 const host=$('#brandWatermarkPreview');if(!host)return;
 host.innerHTML=src?`<img src="${src}" alt="Prévia da marca d’água personalizada">`:'<span>Nenhuma marca d’água personalizada carregada</span>';
}
async function loadBrandWatermarkPreview(){
 try{const r=await fetch('/api/settings/watermark/preview');if(r.ok){const blob=await r.blob();showBrandWatermarkPreview(URL.createObjectURL(blob));}else showBrandWatermarkPreview('');}catch{showBrandWatermarkPreview('');}
}
$('#brandLogo')?.addEventListener('change',()=>{
 const f=$('#brandLogo').files[0];if(!f){loadBrandWatermarkPreview();return;}
 if(f.type!=='image/png'){showBrandWatermarkPreview('');$('#brandStatus').textContent='Escolha um arquivo PNG.';return;}
 if(f.size>2*1024*1024){showBrandWatermarkPreview('');$('#brandStatus').textContent='A marca d’água deve ter no máximo 2 MB.';return;}
 const r=new FileReader();r.onload=()=>showBrandWatermarkPreview(r.result);r.readAsDataURL(f);
});
$('#brandSaveLogo')?.addEventListener('click',async()=>{
 const f=$('#brandLogo').files[0],status=$('#brandStatus');if(!f){status.textContent='Selecione o arquivo PNG da sua marca d’água.';return;}
 if(f.type!=='image/png'){status.textContent='A marca d’água precisa estar em PNG transparente.';return;}
 if(f.size>2*1024*1024){status.textContent='O arquivo ultrapassa o limite de 2 MB.';return;}
 try{const data=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(f);});await request('/api/settings/watermark',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({data,mime:f.type})});status.textContent='Sua marca d’água foi carregada e será aplicada nos próximos vídeos renderizados.';await loadBrandWatermarkPreview();}catch(e){status.textContent=e.message;}
});
$$('.choose-page').forEach(b=>b.addEventListener('click',()=>{const v=b.dataset.page;$('#pageType').value=v;$('#pageTypeStatus').textContent=`Formato selecionado: ${b.parentElement.querySelector('h3').textContent}. Ao criar o próximo projeto, este formato será utilizado.`;tab('create');}));
$('#saveLicenseNote')?.addEventListener('click',()=>{try{localStorage.setItem('ats-license-note',$('#licenseNote').value);$('#licenseStatus').textContent='Anotação salva neste navegador. Isso não ativa nem valida uma licença.';}catch(e){$('#licenseStatus').textContent='Não foi possível salvar a anotação.';}});
let seriesEpisodeDrafts=[];
function renderSeriesEpisodes(){
 const host=$('#seriesEpisodeEditor');if(!host)return;
 $('#seriesEpisodeCount').textContent=`${seriesEpisodeDrafts.length} episódio(s)`;
 host.innerHTML=seriesEpisodeDrafts.length?seriesEpisodeDrafts.map((ep,i)=>`<article class="episodecard" data-episode="${ep.id}">
  <div class="episodehead"><div><span class="eyebrow">EPISÓDIO ${String(i+1).padStart(2,'0')}</span><b>${escapeHtml(ep.title||'Novo episódio')}</b></div><button class="secondary danger" data-remove-episode="${ep.id}">Remover</button></div>
  <label>Nome do vídeo / episódio<input data-episode-title="${ep.id}" value="${escapeHtml(ep.title)}" placeholder="Ex.: Episódio ${i+1} — O começo do mistério"></label>
  <label>Roteiro completo do episódio<textarea data-episode-script="${ep.id}" rows="12" placeholder="Escreva ou cole aqui o roteiro integral deste episódio...">${escapeHtml(ep.script)}</textarea></label>
  <small class="mutedline">${[...ep.script].length.toLocaleString('pt-BR')} caracteres · salvo ao criar os projetos</small>
 </article>`).join(''):'<div class="emptyepisodes">Nenhum episódio adicionado. Clique em “Adicionar episódio” para começar a montar sua série.</div>';
 host.querySelectorAll('[data-episode-title]').forEach(el=>el.addEventListener('input',()=>{const ep=seriesEpisodeDrafts.find(x=>x.id===el.dataset.episodeTitle);if(ep){ep.title=el.value;const b=host.querySelector(`[data-episode="${ep.id}"] .episodehead b`);if(b)b.textContent=ep.title||'Novo episódio';}}));
 host.querySelectorAll('[data-episode-script]').forEach(el=>el.addEventListener('input',()=>{const ep=seriesEpisodeDrafts.find(x=>x.id===el.dataset.episodeScript);if(ep){ep.script=el.value;const small=el.parentElement.querySelector('small');if(small)small.textContent=`${[...ep.script].length.toLocaleString('pt-BR')} caracteres · salvo ao criar os projetos`;}}));
 host.querySelectorAll('[data-remove-episode]').forEach(b=>b.addEventListener('click',()=>{seriesEpisodeDrafts=seriesEpisodeDrafts.filter(x=>x.id!==b.dataset.removeEpisode);renderSeriesEpisodes();}));
}
function addSeriesEpisode(title='',script=''){
 seriesEpisodeDrafts.push({id:crypto.randomUUID(),title:title||`Episódio ${String(seriesEpisodeDrafts.length+1).padStart(2,'0')}`,script});
 renderSeriesEpisodes();
}
$('#addSeriesEpisode')?.addEventListener('click',()=>addSeriesEpisode());
$('#createSeriesProjects')?.addEventListener('click',async()=>{
 const status=$('#seriesStatus'),btn=$('#createSeriesProjects'),name=$('#seriesName').value.trim();
 if(name.length<3){status.textContent='Informe o nome da série.';return;}
 if(!seriesEpisodeDrafts.length){status.textContent='Adicione pelo menos um episódio.';return;}
 const incomplete=seriesEpisodeDrafts.findIndex(x=>!x.title.trim()||!x.script.trim());
 if(incomplete>=0){status.textContent=`Preencha o nome e o roteiro completo do episódio ${incomplete+1}.`;return;}
 const minutes=Math.min(30,Math.max(1,Number($('#seriesDuration').value)||8));
 btn.disabled=true;status.textContent='Criando projetos e salvando os roteiros dos episódios...';
 const created=[];
 try{
  for(let i=0;i<seriesEpisodeDrafts.length;i++){
   const ep=seriesEpisodeDrafts[i];
   status.textContent=`Criando episódio ${i+1} de ${seriesEpisodeDrafts.length}: ${ep.title}`;
   const project=await request('/api/projects',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title:ep.title,pageType:$('#seriesPageType').value,durationSeconds:minutes*60,description:`Série: ${name}`,seriesBible:$('#seriesBible').value})});
   const saved=await request(`/api/projects/${project.project.id}/full-script`,{method:'POST',headers:{'Content-Type':'text/plain; charset=utf-8'},body:ep.script});
   created.push({id:saved.project.id,title:ep.title,scriptCharacters:[...ep.script].length});
  }
  const all=JSON.parse(localStorage.getItem('ats-series')||'[]');
  all.push({name,pageType:$('#seriesPageType').value,durationMinutes:minutes,createdAt:new Date().toISOString(),episodes:created});
  localStorage.setItem('ats-series',JSON.stringify(all));
  status.textContent=`Série criada com ${created.length} episódio(s). Todos os roteiros completos foram salvos integralmente em Meus vídeos.`;
  renderSeriesLibrary();await loadProjects();await loadAllProjects();
 }catch(e){status.textContent=`A criação foi interrompida: ${e.message}. Os episódios já criados continuam salvos em Meus vídeos.`;await loadProjects();}
 finally{btn.disabled=false;}
});
function renderSeriesLibrary(){
 const host=$('#seriesList');if(!host)return;let data=[];try{data=JSON.parse(localStorage.getItem('ats-series')||'[]');}catch{}
 host.innerHTML=data.length?data.map((s,i)=>`<article class="serieslibrary"><div><b>${escapeHtml(s.name)}</b><small>${s.episodes.length} episódio(s) · ${escapeHtml(s.pageType||'')} · ${s.durationMinutes||''} min por episódio</small><div class="episodeopenlist">${s.episodes.map(x=>`<button class="secondary" data-open-series-episode="${escapeHtml(x.id)}">${escapeHtml(x.title)}</button>`).join('')}</div></div><button class="secondary danger" data-delete-series="${i}">Excluir da lista</button></article>`).join(''):'<p class="mutedline">Nenhuma série criada ainda.</p>';
 host.querySelectorAll('[data-open-series-episode]').forEach(b=>b.addEventListener('click',()=>openProject(b.dataset.openSeriesEpisode)));
 host.querySelectorAll('[data-delete-series]').forEach(b=>b.addEventListener('click',()=>{const a=JSON.parse(localStorage.getItem('ats-series')||'[]');a.splice(Number(b.dataset.deleteSeries),1);localStorage.setItem('ats-series',JSON.stringify(a));renderSeriesLibrary();}));
}
function populateSeriesProjects(){renderSeriesLibrary();renderSeriesEpisodes();}
async function loadAllProjects(){const host=$('#allProjectList');if(!host)return;try{const d=await request('/api/projects');host.innerHTML=d.projects.length?d.projects.map(p=>`<article class="projectrow"><div><b>${escapeHtml(p.title)}</b><small>${escapeHtml(p.pageType)} · ${p.sceneCount} cenas · ${new Date(p.createdAt).toLocaleDateString('pt-BR')}</small></div><button class="secondary" data-open-library="${p.id}">Abrir</button></article>`).join(''):'<p class="mutedline">Nenhum projeto criado.</p>';host.querySelectorAll('[data-open-library]').forEach(b=>b.addEventListener('click',()=>{openProject(b.dataset.openLibrary);}));}catch(e){host.textContent=e.message;}}
$('#refreshProjectsPage')?.addEventListener('click',loadAllProjects);
function updateTestProjectStatus(){
 const el=$('#testProjectStatus');if(!el)return;
 el.innerHTML=activeProject?`<b>Projeto ativo: ${escapeHtml(activeProject.title)}</b><span>${activeProject.scenes?.length||0} cena(s). O teste completo exige imagem em todas as cenas, áudio opcional e FFmpeg.</span>`:'<b>Nenhum projeto selecionado</b><span>Crie um projeto curto com uma cena, imagem e narração para testar o renderizador.</span>';
}
$('#runVideoTest')?.addEventListener('click',async()=>{const s=$('#videoTestStatus');try{const h=await request('/api/health');if(!activeProject){s.textContent='Abra um projeto de teste em Meus vídeos ou crie um novo.';return;}const missing=(activeProject.scenes||[]).filter(x=>!x.image);s.textContent=!h.ffmpeg?'FFmpeg não encontrado. Instale-o antes de renderizar.':missing.length?`${missing.length} cena(s) ainda não têm imagem. Gere as imagens primeiro.`:'Condições básicas verificadas. Você pode executar Renderizar MP4 na tela do projeto.';}catch(e){s.textContent=e.message;}});
$('#musicFile')?.addEventListener('change',()=>{const f=$('#musicFile').files[0];if(!f)return;const a=$('#musicPreview');a.src=URL.createObjectURL(f);a.hidden=false;$('#musicInfo').textContent=`Prévia local: ${f.name} · ${(f.size/1024/1024).toFixed(1)} MB. Preencha os dados da licença antes de salvar.`;});
$('#generateAiMusic')?.addEventListener('click',async()=>{const status=$('#aiMusicStatus'),btn=$('#generateAiMusic');if(!activeProject){status.textContent='Abra ou crie um projeto antes de gerar a música.';return;}if(!$('#aiMusicCommercial').checked){status.textContent='Confirme que consultou os termos do Google e as condições de uso comercial/publicação.';return;}const prompt=$('#aiMusicPrompt').value.trim();if(prompt.length<12){status.textContent='Descreva melhor o estilo da trilha.';return;}btn.disabled=true;status.textContent='Gerando música com Google Lyria 3.5. Isso pode levar alguns minutos...';try{const d=await request(`/api/projects/${activeProject.id}/music/generate-ai`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prompt,minutes:Number($('#aiMusicDuration').value)||3,modelId:'lyria-3.5',instrumental:$('#aiMusicInstrumental').checked,commercialConfirmed:true})});activeProject.music=d.music;status.textContent=d.message+' A trilha será mixada na renderização.';}catch(e){status.textContent=e.message;}finally{btn.disabled=false;}});
$('#saveProjectMusic')?.addEventListener('click',async()=>{const f=$('#musicFile')?.files?.[0],status=$('#musicInfo');if(!activeProject){status.textContent='Abra ou crie um projeto antes de adicionar a trilha.';return;}if(!f){status.textContent='Selecione um arquivo de música.';return;}if(!$('#musicCommercial').checked){status.textContent='Bloqueado: confirme que a licença permite uso comercial.';return;}if(!$('#musicYoutubeMonetization').checked){status.textContent='Bloqueado: confirme especificamente a permissão de monetização no YouTube.';return;}const required=['musicSource','musicAuthor','musicProof','musicTerms'];if(required.some(id=>!$('#'+id).value.trim())){status.textContent='Preencha origem, autor, URL do comprovante e condições da licença.';return;}if(f.size>120*1024*1024){status.textContent='O arquivo ultrapassa 120 MB.';return;}try{status.textContent='Salvando trilha e registro da licença...';const data=await new Promise((resolve,reject)=>{const rd=new FileReader();rd.onload=()=>resolve(rd.result);rd.onerror=reject;rd.readAsDataURL(f);});const d=await request(`/api/projects/${activeProject.id}/music`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({data,mime:f.type,volume:Number($('#musicVolume').value)/100,ducking:$('#musicDucking').checked,license:{source:$('#musicSource').value,author:$('#musicAuthor').value,proofUrl:$('#musicProof').value,terms:$('#musicTerms').value,creditText:$('#musicCredit').value,commercialUse:$('#musicCommercial').checked,youtubeMonetization:$('#musicYoutubeMonetization').checked,creditRequired:$('#musicCreditRequired').checked}})});activeProject.music=d.music;status.textContent=d.message+(d.music.license.creditRequired?' Inclua o crédito informado na descrição do vídeo.':'');}catch(e){status.textContent=e.message;}});

async function loadHealth(){try{const h=await request('/api/health');$('#healthStatus').innerHTML=`<i></i> ${h.ffmpeg?'FFmpeg pronto':'FFmpeg não instalado'}`;$('#healthStatus').title=h.ffmpeg?'Renderização MP4 disponível':'Instale FFmpeg e adicione ao PATH para renderizar MP4.';}catch{}}
async function loadSettings(){try{const s=await request('/api/settings');$('#model').value=s.model||'gemini-3.1-flash-image';$('#elevenVoiceId').value=s.elevenVoiceId||'';$('#elevenModel').value=s.elevenModel||'eleven_multilingual_v2';$('#elevenVoiceId').value=s.elevenVoiceId||'';$('#channelName').value=s.channelName||'';$('#watermark').value=s.watermark||'';if($('#brandChannel'))$('#brandChannel').value=s.channelName||'';if($('#brandWatermark'))$('#brandWatermark').value=s.watermark||'';$('#settingsStatus').textContent=`${s.configured?'Gemini configurado.':'Configure sua chave Gemini.'} ${s.elevenConfigured?'ElevenLabs configurada.':'ElevenLabs ainda não configurada.'}`;}catch(e){$('#settingsStatus').textContent=e.message;}}
$('#saveSettings').addEventListener('click',async()=>{const status=$('#settingsStatus');status.textContent='Salvando...';try{const payload={geminiApiKey:$('#apiKey').value,elevenLabsApiKey:$('#elevenApiKey').value,elevenLabsVoiceId:$('#elevenVoiceId').value,elevenLabsModel:$('#elevenModel').value,model:$('#model').value,channelName:$('#channelName').value,watermark:$('#watermark').value};const d=await request('/api/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});$('#apiKey').value='';$('#elevenApiKey').value='';status.textContent=`Ajustes salvos localmente. Gemini: ${d.configured?'configurado':'não configurado'}. ElevenLabs: ${d.elevenConfigured?'configurada':'não configurada'}.`;}catch(e){status.textContent=e.message;}});
async function loadProjects(){const el=$('#projectList');if(!el)return;try{const d=await request('/api/projects');if(!d.projects.length){el.innerHTML='<p class="mutedline">Nenhum projeto criado ainda.</p>';return;}el.innerHTML=d.projects.map(p=>`<article class="projectrow"><div><b>${escapeHtml(p.title)}</b><small>${escapeHtml(p.pageType)} · ${p.sceneCount} cenas · ${new Date(p.createdAt).toLocaleDateString('pt-BR')}</small></div><button class="secondary" data-open-project="${p.id}">Abrir</button></article>`).join('');el.querySelectorAll('[data-open-project]').forEach(b=>b.addEventListener('click',()=>openProject(b.dataset.openProject)));}catch(e){el.textContent=e.message;}}
async function openProject(id){
 const d=await request(`/api/projects/${id}`);activeProject=d.project;
 $('#theme').value=activeProject.title;$('#pageType').value=activeProject.pageType;
 const raw=await fetch(`/api/projects/${id}/full-script`);$('#fullScript').value=raw.ok?await raw.text():'';
 $('#saveFullScript').disabled=false;$('#analyzeWithClaude').disabled=false;$('#fullScriptCounter').textContent=`${[...$('#fullScript').value].length.toLocaleString('pt-BR')} caracteres`;$('#fullScriptStatus').textContent=$('#fullScript').value?`Roteiro integral carregado · ${[...$('#fullScript').value].length.toLocaleString('pt-BR')} caracteres.`:'Nenhum roteiro completo salvo ainda.';
 $('#activeProject').textContent=`Projeto ativo: ${activeProject.title} (${activeProject.id})`;
 $('#generate').disabled=!activeProject.scenes?.length;$('#genStatus').textContent='Projeto carregado.';
 renderScenes();renderSources();tab('create');
}
$('#duration')?.addEventListener('input',()=>{const n=Number($('#duration').value);if(n>30)$('#duration').value='30';if(n<1&&$('#duration').value!=='')$('#duration').value='1';});
$('#createProject').addEventListener('click',async()=>{
 const status=$('#genStatus'),btn=$('#createProject'),title=$('#theme').value.trim(),fullScript=$('#fullScript').value;
 if(title.length<3){status.textContent='Informe o nome do vídeo (mínimo de 3 caracteres).';return;}
 btn.disabled=true;status.textContent='Criando projeto e guardando o roteiro completo...';
 try{
  const payload={title,pageType:$('#pageType').value,durationSeconds:Math.min(1800,Math.max(60,(Number($('#duration').value)||8)*60))};
  const d=await request('/api/projects',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
  activeProject=d.project;
  if(fullScript.trim()){
   const saved=await request(`/api/projects/${activeProject.id}/full-script`,{method:'POST',headers:{'Content-Type':'text/plain; charset=utf-8'},body:fullScript});
   activeProject=saved.project;
  }
  const sceneNarration=$('#narration').value.trim(),visualPrompt=$('#prompt').value.trim();
  if(sceneNarration||visualPrompt){
   const script={logline:title,chapters:[{title:'Abertura',startScene:1}],scenes:[{id:'scene-001',title:$('#sceneName').value||'Cena 01',narration:sceneNarration||'Cena sem narração cadastrada.',visualPrompt,durationSeconds:10}]};
   const saved=await request(`/api/projects/${activeProject.id}/script`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(script)});
   activeProject=saved.project;
  }
  $('#activeProject').textContent=`Projeto ativo: ${activeProject.title} (${activeProject.id})`;
  $('#saveFullScript').disabled=false;$('#analyzeWithClaude').disabled=false;$('#fullScriptCounter').textContent=`${[...fullScript].length.toLocaleString('pt-BR')} caracteres`;$('#fullScriptStatus').textContent=fullScript.trim()?`Roteiro integral salvo · ${[...fullScript].length.toLocaleString('pt-BR')} caracteres.`:'Projeto criado. Você pode inserir o roteiro completo e salvá-lo.';
  $('#generate').disabled=!activeProject.scenes?.length;
  status.textContent='Projeto criado. O roteiro completo está salvo; agora você pode organizar as cenas e produzir o vídeo.';
  renderScenes();renderSources();await loadProjects();
 }catch(e){status.textContent=e.message;}finally{btn.disabled=false;}
});
async function saveFullScript(){
 if(!activeProject){$('#fullScriptStatus').textContent='Crie ou abra um projeto antes de salvar o roteiro.';return false;}
 const status=$('#fullScriptStatus'),fullScript=$('#fullScript').value;
 status.textContent='Salvando roteiro completo...';
 try{
  const d=await request(`/api/projects/${activeProject.id}/full-script`,{method:'POST',headers:{'Content-Type':'text/plain; charset=utf-8'},body:fullScript});
  activeProject=d.project;status.textContent=`Roteiro completo salvo integralmente · ${[...fullScript].length.toLocaleString('pt-BR')} caracteres.`;
  await loadProjects();return true;
 }catch(e){status.textContent=e.message;return false;}
}
$('#fullScript')?.addEventListener('input',()=>{const el=$('#fullScriptCounter');if(el)el.textContent=`${[...$('#fullScript').value].length.toLocaleString('pt-BR')} caracteres`;});
$('#saveFullScript')?.addEventListener('click',saveFullScript);
$('#analyzeWithClaude')?.addEventListener('click',async()=>{
 if(!activeProject){$('#claudeAnalysisStatus').textContent='Crie ou abra um projeto primeiro.';return;}
 const btn=$('#analyzeWithClaude'),status=$('#claudeAnalysisStatus');
 btn.disabled=true;status.textContent='Salvando o roteiro e iniciando o Claude Code. A análise pode levar alguns minutos...';
 try{
  const raw=$('#fullScript').value;
  const saveResponse=await fetch(`/api/projects/${activeProject.id}/full-script`,{method:'POST',headers:{'Content-Type':'text/plain; charset=utf-8'},body:raw});
  const saved=await saveResponse.json();if(!saveResponse.ok)throw Error(saved.error||`Erro HTTP ${saveResponse.status}`);
  status.textContent='Claude Code está lendo o roteiro integral, estruturando capítulos e dividindo a narrativa em cenas...';
  const d=await request(`/api/projects/${activeProject.id}/claude/analyze`,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
  activeProject=d.project;$('#generate').disabled=!activeProject.scenes?.length;
  status.textContent=`Análise concluída: ${d.sceneCount} cenas · ${Math.ceil(d.totalDurationSeconds/60)} min planejados. ${d.notes?.length?`Observações: ${d.notes.join(' | ')}`:''}`;
  $('#fullScriptStatus').textContent='Roteiro original preservado. A estrutura de cenas foi criada pelo Claude Code.';
  renderScenes();renderSources();await loadProjects();
 }catch(e){status.textContent=e.message;}
 finally{btn.disabled=false;}
});


function updatePreview(){const scene=activeProject?.scenes?.find(s=>s.image);if(scene){$('#previewCanvas').innerHTML=`<img src="/${escapeHtml(scene.image.relativePath)}?v=${Date.now()}" alt="Imagem gerada pelo Gemini">${scene.image.illustration?'<span class="illustration">ILUSTRAÇÃO</span>':''}`;}else if($('#previewCanvas'))$('#previewCanvas').innerHTML='<div class="placeholder"><div>✦</div><b>Sua imagem aparecerá aqui</b><small>Geração em tela cheia · Gemini</small></div>'; }
function renderScenes(){const host=$('#sceneEditor');if(!activeProject){host.innerHTML='<p class="mutedline">Crie ou abra um projeto para editar suas cenas.</p>';return;}const scenes=activeProject.scenes||[];if(!scenes.length){host.innerHTML='<p class="mutedline">Nenhuma cena. Use “Adicionar cena”.</p>';updatePreview();return;}host.innerHTML=scenes.map((s,i)=>`<article class="sceneitem" data-scene="${escapeHtml(s.id)}"><div class="scenehead"><b>${String(i+1).padStart(2,'0')} · ${escapeHtml(s.title||'Cena')}</b><small>${s.image?'Imagem pronta':'Imagem pendente'} · ${Number(s.durationSeconds)||8}s</small></div><div class="scenegrid"><div><label>Título da cena<input data-field="title" value="${escapeHtml(s.title)}"></label><label>Duração (segundos)<input data-field="durationSeconds" type="number" min="1" max="120" value="${Number(s.durationSeconds)||8}"></label>${s.image?`<img class="sceneimage" src="/${escapeHtml(s.image.relativePath)}?v=${Date.now()}" alt="Imagem da cena">`:''}</div><div><label>Narração<textarea data-field="narration">${escapeHtml(s.narration)}</textarea></label><label>Prompt visual Gemini<textarea data-field="visualPrompt">${escapeHtml(s.visualPrompt)}</textarea></label></div></div><div class="sceneactions"><button class="secondary" data-move-scene="up:${escapeHtml(s.id)}" ${i===0?'disabled':''}>↑ Subir</button><button class="secondary" data-move-scene="down:${escapeHtml(s.id)}" ${i===scenes.length-1?'disabled':''}>↓ Descer</button><button class="secondary" data-generate-scene="${escapeHtml(s.id)}">${s.image?'Regenerar imagem':'Gerar imagem'} ✦</button><button class="secondary danger" data-remove-scene="${escapeHtml(s.id)}">Excluir cena</button></div></article>`).join('');host.querySelectorAll('[data-move-scene]').forEach(b=>b.addEventListener('click',()=>{const [direction,id]=b.dataset.moveScene.split(':');const index=activeProject.scenes.findIndex(s=>s.id===id),next=direction==='up'?index-1:index+1;if(next<0||next>=activeProject.scenes.length)return;const [item]=activeProject.scenes.splice(index,1);activeProject.scenes.splice(next,0,item);renderScenes();}));host.querySelectorAll('[data-generate-scene]').forEach(b=>b.addEventListener('click',()=>generateScene(b.dataset.generateScene,b)));host.querySelectorAll('[data-remove-scene]').forEach(b=>b.addEventListener('click',()=>{activeProject.scenes=activeProject.scenes.filter(s=>s.id!==b.dataset.removeScene);renderScenes();}));updatePreview();}
function renderSources(){const host=$('#sourceList');if(!host||!activeProject)return;const sources=activeProject.sources||[];host.innerHTML=sources.length?sources.map(x=>`<div class="sourceitem"><div><b>${escapeHtml(x.title)}</b><small>${escapeHtml(x.publisher||'Fonte')} · ${escapeHtml(x.supports||'')}</small><a href="${escapeHtml(x.url)}" target="_blank" rel="noreferrer">${escapeHtml(x.url)}</a></div><button class="secondary danger" data-delete-source="${escapeHtml(x.id)}">Excluir</button></div>`).join(''):'<p class="mutedline">Nenhuma fonte registrada.</p>';host.querySelectorAll('[data-delete-source]').forEach(b=>b.addEventListener('click',async()=>{try{const d=await request(`/api/projects/${activeProject.id}/sources/${b.dataset.deleteSource}`,{method:'DELETE'});activeProject=d.project;renderSources();}catch(e){$('#productionStatus').textContent=e.message;}}));}
function collectScenes(){return [...$('#sceneEditor').querySelectorAll('.sceneitem')].map(card=>{const old=activeProject.scenes.find(s=>s.id===card.dataset.scene)||{};const val=k=>card.querySelector(`[data-field="${k}"]`)?.value??'';return {...old,id:card.dataset.scene,title:val('title'),narration:val('narration'),visualPrompt:val('visualPrompt'),durationSeconds:Number(val('durationSeconds'))||8};});}
$('#addScene').addEventListener('click',()=>{if(!activeProject){$('#productionStatus').textContent='Crie ou abra um projeto primeiro.';return;}activeProject.scenes.push({id:`scene-${crypto.randomUUID().slice(0,8)}`,title:`Cena ${String(activeProject.scenes.length+1).padStart(2,'0')}`,narration:'',visualPrompt:'',durationSeconds:8,image:null});renderScenes();});
$('#saveScript').addEventListener('click',saveScript);
async function saveScript(){if(!activeProject)return;const status=$('#productionStatus');status.textContent='Salvando roteiro...';try{if($('#fullScript')){const fr=await fetch(`/api/projects/${activeProject.id}/full-script`,{method:'POST',headers:{'Content-Type':'text/plain; charset=utf-8'},body:$('#fullScript').value});const fsaved=await fr.json();if(!fr.ok)throw Error(fsaved.error||`Erro HTTP ${fr.status}`);activeProject=fsaved.project;}const scenes=collectScenes();const d=await request(`/api/projects/${activeProject.id}/script`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({logline:activeProject.script?.logline||activeProject.title,chapters:activeProject.script?.chapters||[],sources:activeProject.sources||[],scenes})});activeProject=d.project;status.textContent=`Roteiro salvo: ${d.sceneCount} cenas.`;renderScenes();renderSources();await loadProjects();}catch(e){status.textContent=e.message;}}
async function generateScene(id,button){await saveScript();const status=$('#productionStatus');if(button)button.disabled=true;status.textContent=`Gerando imagem da cena ${id} no Gemini...`;try{const d=await request(`/api/projects/${activeProject.id}/scenes/${id}/image`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({})});const fresh=await request(`/api/projects/${activeProject.id}`);activeProject=fresh.project;status.textContent=`Imagem da cena ${id} gerada e salva.`;renderScenes();const first=activeProject.scenes.find(s=>s.id===id);if(first?.image)$('#previewCanvas').innerHTML=`<img src="/${first.image.relativePath}?v=${Date.now()}" alt="Imagem gerada pelo Gemini">${first.image.illustration?'<span class="illustration">ILUSTRAÇÃO</span>':''}`;}catch(e){status.textContent=e.message;}finally{if(button)button.disabled=false;}}
$('#generate').addEventListener('click',async()=>{if(!activeProject)return;await generateScene(activeProject.scenes[0]?.id);});
$('#generateAll').addEventListener('click',async()=>{if(!activeProject)return;const status=$('#productionStatus');$('#generateAll').disabled=true;try{await saveScript();status.textContent='Gerando imagens pendentes em sequência. Isso pode levar alguns minutos...';const d=await request(`/api/projects/${activeProject.id}/images/generate-all`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({onlyMissing:true})});activeProject=d.project;renderScenes();status.textContent=`Concluído: ${d.generated.length} imagens geradas.${d.errors.length?` Falhas: ${d.errors.map(x=>x.sceneId+': '+x.error).join(' | ')}`:''}`;}catch(e){status.textContent=e.message;}finally{$('#generateAll').disabled=false;}});
$('#generateElevenAudio').addEventListener('click',async()=>{if(!activeProject){$('#productionStatus').textContent='Crie ou abra um projeto primeiro.';return;}const btn=$('#generateElevenAudio'),status=$('#productionStatus');btn.disabled=true;try{await saveScript();status.textContent='Gerando narração com ElevenLabs...';const d=await request(`/api/projects/${activeProject.id}/elevenlabs/narration`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({})});activeProject.audio=d.audio;status.textContent='Narração ElevenLabs gerada e anexada ao projeto. Ela será usada na renderização MP4.';}catch(e){status.textContent=e.message;}finally{btn.disabled=false;}});
$('#uploadAudio').addEventListener('click',async()=>{if(!activeProject)return;const f=$('#audioFile').files[0],status=$('#productionStatus');if(!f){status.textContent='Selecione um arquivo de narração.';return;}if(f.size>120*1024*1024){status.textContent='O arquivo deve ter até 120 MB.';return;}status.textContent='Enviando narração...';try{const data=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsDataURL(f);});const d=await request(`/api/projects/${activeProject.id}/audio`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({data,mime:f.type})});activeProject.audio=d.audio;status.textContent=`Áudio enviado (${(f.size/1024/1024).toFixed(1)} MB).`;}catch(e){status.textContent=e.message;}});
$('#downloadSrt').addEventListener('click',()=>{if(!activeProject)return;window.open(`/api/projects/${activeProject.id}/subtitles.srt`,'_blank');});
$('#addSource').addEventListener('click',async()=>{if(!activeProject)return;try{const d=await request(`/api/projects/${activeProject.id}/sources`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title:$('#sourceTitle').value,publisher:$('#sourcePublisher').value,url:$('#sourceUrl').value,supports:$('#sourceSupports').value})});activeProject=d.project;['sourceTitle','sourcePublisher','sourceUrl','sourceSupports'].forEach(id=>$('#'+id).value='');renderSources();$('#productionStatus').textContent='Fonte registrada no projeto.';}catch(e){$('#productionStatus').textContent=e.message;}});
$('#saveWatermark').addEventListener('click',async()=>{const f=$('#watermarkFile').files[0];if(!f){$('#settingsStatus').textContent='Selecione um arquivo PNG.';return;}if(f.type!=='image/png'){ $('#settingsStatus').textContent='A marca deve ser PNG transparente.';return;}try{const data=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(f);});await request('/api/settings/watermark',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({data,mime:f.type})});$('#settingsStatus').textContent='Logotipo PNG salvo. Será aplicado no canto do vídeo.';}catch(e){$('#settingsStatus').textContent=e.message;}});
$('#renderVideo').addEventListener('click',async()=>{if(!activeProject)return;const status=$('#productionStatus'),btn=$('#renderVideo');btn.disabled=true;$('#renderLink').hidden=true;try{await saveScript();status.textContent='Renderizando vídeo 1080p com FFmpeg. Aguarde...';const d=await request(`/api/projects/${activeProject.id}/render`,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});$('#renderLink').href=d.downloadUrl;$('#renderLink').hidden=false;$('#renderLink').textContent='Baixar vídeo MP4';status.textContent=`Vídeo renderizado: ${d.render.durationSeconds}s · 1920×1080 · ${d.render.withAudio?'com narração':'sem áudio'}.`;}catch(e){status.textContent=e.message;}finally{btn.disabled=false;}});
$('#refreshProjects')?.addEventListener('click',loadProjects);
loadHealth();loadSettings();loadProjects();


// Voice provider center
let selectedProvider='eleven', selectedElevenVoice='', selectedPiperVoice='', selectedWindowsVoice='';
$$('[data-provider]').forEach(b=>b.addEventListener('click',()=>{selectedProvider=b.dataset.provider;$$('[data-provider]').forEach(x=>x.classList.toggle('active',x===b));['eleven','piper','windows'].forEach(k=>$('#provider-'+k).hidden=k!==selectedProvider);}));
function voiceCard(v,provider){const id=escapeHtml(v.id||v.voice_id||v.Name||v.name);const name=escapeHtml(v.name||v.Name||v.id);const desc=escapeHtml(v.description||v.category||v.Culture||v.Gender||'Voz disponível');const selected=(provider==='eleven'?selectedElevenVoice:provider==='piper'?selectedPiperVoice:selectedWindowsVoice)===(v.id||v.voice_id||v.Name||v.name);return `<article class="voicecard ${selected?'selected':''}"><b>${name}</b><small>${desc} ${v.labels?.accent? '· '+escapeHtml(v.labels.accent):''}</small>${provider==='eleven'?(v.previewUrl?`<audio controls preload="none" src="${escapeHtml(v.previewUrl)}"></audio>`:'<small>Prévia gerada sob demanda</small>'):''}<div><button class="secondary" data-vpreview="${id}" data-vprovider="${provider}">▶ Ouvir</button><button class="primary" data-vselect="${id}" data-vprovider="${provider}">Usar esta voz</button></div></article>`;}
function bindVoiceCards(host){host.querySelectorAll('[data-vselect]').forEach(b=>b.addEventListener('click',async()=>{const provider=b.dataset.vprovider,id=b.dataset.vselect;try{if(provider==='eleven'){await request('/api/elevenlabs/select-voice',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({voiceId:id})});selectedElevenVoice=id;$('#elevenVoiceId').value=id;}else if(provider==='piper'){await request('/api/piper/select-voice',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({voiceId:id})});selectedPiperVoice=id;}else{await request('/api/windows/select-voice',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({voiceName:id})});selectedWindowsVoice=id;}$('#voiceStatus').textContent='Voz selecionada.';host.querySelectorAll('.voicecard').forEach(c=>c.classList.remove('selected'));b.closest('.voicecard').classList.add('selected');}catch(e){$('#voiceStatus').textContent=e.message;}}));host.querySelectorAll('[data-vpreview]').forEach(b=>b.addEventListener('click',async()=>{const provider=b.dataset.vprovider,id=b.dataset.vpreview;try{if(provider==='eleven'){const d=await request(`/api/elevenlabs/preview/${encodeURIComponent(id)}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:$('#voiceTestText').value})});const audio=new Audio(`data:${d.mime};base64,${d.audio}`);await audio.play();}else{const d=await request('/api/voice/preview-local',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({provider,voiceId:id,text:$('#voiceTestText').value})});const audio=new Audio(`data:${d.mime};base64,${d.audio}`);await audio.play();}}catch(e){$('#voiceStatus').textContent=e.message;}}));}
$('#authenticateEleven').addEventListener('click',async()=>{const key=$('#elevenApiKey').value;const status=$('#voiceStatus');status.textContent='Validando chave e consultando assinatura...';try{const d=await request('/api/elevenlabs/auth',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({apiKey:key})});status.textContent='Chave autenticada com sucesso. Plano: '+(d.usage.tier||'consultado')+'.';await loadElevenUsage();$('#elevenApiKey').value='';}catch(e){status.textContent=e.message;}});
let elevenNextPageToken=null;async function loadElevenVoicePage(reset=true){const host=$('#elevenVoiceList');if(reset){host.innerHTML='<p class="mutedline">Carregando vozes...</p>';elevenNextPageToken=null;}try{const url='/api/elevenlabs/voices'+(!reset&&elevenNextPageToken?'?next_page_token='+encodeURIComponent(elevenNextPageToken):'');const d=await request(url);selectedElevenVoice=d.selectedVoiceId||selectedElevenVoice;const markup=d.voices.map(v=>voiceCard(v,'eleven')).join('');if(reset)host.innerHTML=markup||'<p class="mutedline">Nenhuma voz foi retornada pela conta.</p>';else host.insertAdjacentHTML('beforeend',markup);bindVoiceCards(host);elevenNextPageToken=d.nextPageToken||null;$('#loadMoreElevenVoices').hidden=!d.hasMore;await loadElevenUsage();}catch(e){host.textContent=e.message;}}$('#loadElevenVoices').addEventListener('click',()=>loadElevenVoicePage(true));$('#loadMoreElevenVoices').addEventListener('click',()=>loadElevenVoicePage(false));
async function loadElevenUsage(){try{const d=await request('/api/elevenlabs/usage');$('#elevenUsage').innerHTML=`<b>${escapeHtml(d.tier||'Plano')}</b> · ${Number(d.characterCount||0).toLocaleString('pt-BR')} de ${Number(d.characterLimit||0).toLocaleString('pt-BR')} caracteres usados · <b>${Number(d.remaining||0).toLocaleString('pt-BR')} restantes</b>${d.resetAt?' · Renovação: '+new Date(d.resetAt*1000).toLocaleDateString('pt-BR'):''}`;}catch(e){$('#elevenUsage').textContent=e.message;}}
let voiceRecorder=null,voiceRecordChunks=[];$('#startVoiceRecord').addEventListener('click',async()=>{try{const stream=await navigator.mediaDevices.getUserMedia({audio:true});voiceRecordChunks=[];voiceRecorder=new MediaRecorder(stream);voiceRecorder.ondataavailable=e=>{if(e.data.size)voiceRecordChunks.push(e.data);};voiceRecorder.onstop=()=>{const blob=new Blob(voiceRecordChunks,{type:voiceRecorder.mimeType||'audio/webm'});const file=new File([blob],'amostra-voz.webm',{type:blob.type});const dt=new DataTransfer();dt.items.add(file);$('#cloneVoiceFile').files=dt.files;$('#recordStatus').textContent=`Gravação pronta: ${(blob.size/1024).toFixed(0)} KB`;stream.getTracks().forEach(t=>t.stop());};voiceRecorder.start();$('#startVoiceRecord').disabled=true;$('#stopVoiceRecord').disabled=false;$('#recordStatus').textContent='Gravando...';}catch(e){$('#recordStatus').textContent='Não foi possível acessar o microfone: '+e.message;}});$('#stopVoiceRecord').addEventListener('click',()=>{if(voiceRecorder&&voiceRecorder.state!=='inactive'){voiceRecorder.stop();$('#startVoiceRecord').disabled=false;$('#stopVoiceRecord').disabled=true;}});
$('#cloneVoiceButton').addEventListener('click',async()=>{const file=$('#cloneVoiceFile').files[0],name=$('#cloneVoiceName').value.trim(),consent=$('#cloneConsent').checked;if(!file||!name){$('#voiceStatus').textContent='Informe o nome e selecione uma gravação.';return;}if(!consent){$('#voiceStatus').textContent='Confirme que tem direito de clonar esta voz.';return;}if(file.size>30*1024*1024){$('#voiceStatus').textContent='O áudio deve ter até 30 MB.';return;}const reader=new FileReader();reader.onload=async()=>{try{const d=await request('/api/elevenlabs/clone',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,data:reader.result,mime:file.type,consent})});$('#voiceStatus').textContent=d.message;$('#cloneVoiceFile').value='';await $('#loadElevenVoices').click();}catch(e){$('#voiceStatus').textContent=e.message;}};reader.readAsDataURL(file);});
$('#refreshElevenUsage').addEventListener('click',loadElevenUsage);
$('#checkPiper').addEventListener('click',loadPiperStatus);
async function loadPiperStatus(){try{const d=await request('/api/piper/status');$('#piperStatus').textContent=d.installed?`Piper instalado (${d.python}). Modelos em ${d.voiceDir}.`:'Piper não instalado. Use Instalar Piper.';const host=$('#piperVoiceList');const known=['pt_BR-cadu-medium','pt_BR-edresson-low','pt_BR-faber-medium','pt_BR-jeff-medium'];host.innerHTML=known.map(id=>{const found=d.voices.find(v=>v.id===id);return voiceCard({id,name:id.replace('pt_BR-','').replace(/-(medium|low)$/,''),description:found?'Instalada':'Disponível para baixar'},'piper')+(!found?`<button class="secondary" data-piper-download="${id}">Baixar modelo</button>`:'');}).join('');selectedPiperVoice=d.selectedVoice||'';bindVoiceCards(host);host.querySelectorAll('[data-piper-download]').forEach(b=>b.addEventListener('click',async()=>{b.disabled=true;try{await request('/api/piper/download-voice',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({voiceId:b.dataset.piperDownload})});await loadPiperStatus();}catch(e){$('#piperStatus').textContent=e.message;}finally{b.disabled=false;}}));}catch(e){$('#piperStatus').textContent=e.message;}}
$('#installPiper').addEventListener('click',async()=>{const el=$('#piperStatus');el.textContent='Instalando Piper. Aguarde...';try{const d=await request('/api/piper/install',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});el.textContent=d.message;await loadPiperStatus();}catch(e){el.textContent=e.message;}});
$('#loadWindowsVoices').addEventListener('click',async()=>{const host=$('#windowsVoiceList');host.textContent='Consultando vozes do Windows...';try{const d=await request('/api/windows/voices',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});host.innerHTML=d.voices.map(v=>voiceCard({id:v.Name,name:v.Name,description:`${v.Culture||''} · ${v.Gender||''}`},'windows')).join('');bindVoiceCards(host);}catch(e){host.textContent=e.message;}});
$('#previewSelectedVoice').addEventListener('click',async()=>{if(!activeProject){$('#voiceStatus').textContent='Abra um projeto para gerar a narração completa.';return;}try{await saveScript();const provider=selectedProvider;if(provider==='eleven'){const id=$('#elevenVoiceId').value;if(!id)throw Error('Selecione uma voz ElevenLabs primeiro.');}let d;if(provider==='eleven'){d=await request(`/api/projects/${activeProject.id}/elevenlabs/narration`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({})});}else{d=await request('/api/voice/generate-project',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({projectId:activeProject.id,provider})});}activeProject.audio=d.audio;$('#voiceStatus').textContent=(d.message||'Narração gerada.')+' O áudio será usado na renderização.';}catch(e){$('#voiceStatus').textContent=e.message;}});


// Catálogo expandido de modelos visuais do Auto Tube Studio.
// Os modelos foram recriados a partir das categorias identificáveis nas referências e da documentação fornecida.
const ATS_MODELS=window.ATS_PAGE_MODELS||[];
function modelArt(m){return `<div class="page-model-art" style="--model-bg:${m.bg};--model-accent:${m.accent}"><div><span class="art-icon">${escapeHtml(m.icon)}</span><span class="art-label">${escapeHtml(m.name)}</span><span class="art-sub">AUTO TUBE STUDIO</span></div></div>`;}
function fillPageModelSelects(){
 const opts=ATS_MODELS.map(m=>`<option value="${escapeHtml(m.id)}">${escapeHtml(m.icon)} ${escapeHtml(m.name)}</option>`).join('');
 ['pageType','seriesPageType'].forEach(id=>{const el=$('#'+id);if(!el)return;const old=el.value;el.innerHTML=opts;el.value=ATS_MODELS.some(m=>m.id===old)?old:'vidas-ficcao';});
}
function renderPageModelGallery(){
 const grid=$('#pageModelGrid');if(!grid)return;
 const query=($('#pageModelSearch')?.value||'').trim().toLocaleLowerCase('pt-BR');
 const group=$('#pageModelGroup')?.value||'all';
 const active=$('#pageType')?.value||'vidas-ficcao';
 const list=ATS_MODELS.filter(m=>(group==='all'||m.group===group)&&(!query||`${m.name} ${m.description}`.toLocaleLowerCase('pt-BR').includes(query)));
 grid.innerHTML=list.map(m=>`<button type="button" class="page-model-card ${m.id===active?'selected':''}" data-model-detail="${m.id}">${modelArt(m)}<h3>${escapeHtml(m.icon)} ${escapeHtml(m.name)}</h3><p>${escapeHtml(m.description)}</p><div class="model-group">${escapeHtml(m.group)}</div></button>`).join('')||'<p class="mutedline">Nenhum modelo encontrado.</p>';
}
function showPageModelDetail(id){
 const m=ATS_MODELS.find(x=>x.id===id);if(!m)return;
 const detail=$('#pageModelDetail');if(!detail)return;
 detail.hidden=false;
 detail.innerHTML=`${modelArt(m)}<div><h3>${escapeHtml(m.icon)} ${escapeHtml(m.name)}</h3><p>${escapeHtml(m.description)}</p><p><b>Direção visual:</b> ${escapeHtml(m.style)}. O modelo orienta os prompts de imagem, a composição e a linguagem visual, sem inserir textos ou marcas dentro das imagens geradas.</p><div class="toolbar"><button class="primary" data-apply-model="${m.id}">Usar este modelo</button><button class="secondary" data-create-model="${m.id}">Criar vídeo neste estilo</button></div></div>`;
}
function applyPageModel(id,goCreate=false){
 const m=ATS_MODELS.find(x=>x.id===id);if(!m)return;
 if($('#pageType'))$('#pageType').value=id;
 if($('#seriesPageType'))$('#seriesPageType').value=id;
 const status=$('#pageTypeStatus');if(status)status.textContent=`Modelo selecionado: ${m.name}. Ele será aplicado aos próximos projetos.`;
 renderPageModelGallery();showPageModelDetail(id);
 if(goCreate)tab('create');
}
fillPageModelSelects();
renderPageModelGallery();
$('#pageModelSearch')?.addEventListener('input',renderPageModelGallery);
$('#pageModelGroup')?.addEventListener('change',renderPageModelGallery);
$('#pageModelGrid')?.addEventListener('click',e=>{const b=e.target.closest('[data-model-detail]');if(b)showPageModelDetail(b.dataset.modelDetail);});
$('#pageModelDetail')?.addEventListener('click',e=>{
 const a=e.target.closest('[data-apply-model]');if(a){applyPageModel(a.dataset.applyModel,false);return;}
 const c=e.target.closest('[data-create-model]');if(c)applyPageModel(c.dataset.createModel,true);
});
$$('.choose-page').forEach(b=>b.addEventListener('click',()=>applyPageModel(b.dataset.page,true)));

// Módulo de efeitos sonoros licenciados
$('#sfxFile')?.addEventListener('change',()=>{const f=$('#sfxFile').files[0];if(!f)return;const p=$('#sfxPreview');p.src=URL.createObjectURL(f);p.hidden=false;$('#sfxStatus').textContent=`Prévia: ${f.name}`;});
$('#saveSfx')?.addEventListener('click',async()=>{const f=$('#sfxFile')?.files?.[0],status=$('#sfxStatus'),btn=$('#saveSfx');if(!activeProject){status.textContent='Abra ou crie um projeto antes de adicionar efeitos.';return;}if(!f){status.textContent='Selecione um arquivo de efeito sonoro.';return;}if(!$('#sfxCommercial').checked){status.textContent='Bloqueado: confirme a autorização comercial e monetização.';return;}const source=$('#sfxSource').value.trim(),author=$('#sfxAuthor').value.trim(),proof=$('#sfxProof').value.trim(),terms=$('#sfxTerms').value.trim();if(!source||!author||!(proof.startsWith('https://')||proof.startsWith('http://'))||!terms){status.textContent='Preencha origem, autor, URL e condições da licença.';return;}if(f.size>40*1024*1024){status.textContent='O efeito ultrapassa 40 MB.';return;}btn.disabled=true;try{const data=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(f);});const payload={effects:[{data,mime:f.type,label:$('#sfxLabel').value.trim()||f.name,startSeconds:Number($('#sfxStart').value)||0,volume:(Number($('#sfxVolume').value)||25)/100,license:{source,author,proofUrl:proof,terms,commercialUse:true,youtubeMonetization:true,verifiedByUser:true}}]};const d=await request(`/api/projects/${activeProject.id}/sound-effects`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});status.textContent=d.message;$('#sfxFile').value='';$('#sfxPreview').hidden=true;$('#sfxList').innerHTML=(activeProject.soundEffects||[]).concat(d.effects).map(e=>`<div class="listitem">${escapeHtml(e.label)} — ${Number(e.startSeconds).toFixed(1)}s</div>`).join('');activeProject.soundEffects=(activeProject.soundEffects||[]).concat(d.effects);}catch(e){status.textContent=e.message;}finally{btn.disabled=false;}});
