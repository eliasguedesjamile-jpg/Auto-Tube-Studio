@echo off
setlocal
cd /d "%~dp0"
set "NODE_EXE=%~dp0tools\node-runtime\node.exe"
if not exist "%NODE_EXE%" (
  echo.
  echo Preparando o Node.js portatil oficial. Isso so sera necessario na primeira inicializacao.
  echo O Node.js sera extraido dentro da pasta tools, sem instalacao no Windows.
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $dest='%~dp0tools\node-runtime'; $tmp=Join-Path $env:TEMP 'ats-node-v24.22.0.zip'; New-Item -ItemType Directory -Force -Path $dest ^| Out-Null; Invoke-WebRequest -Uri 'https://nodejs.org/dist/v24.22.0/node-v24.22.0-win-x64.zip' -OutFile $tmp; Expand-Archive -LiteralPath $tmp -DestinationPath $env:TEMP -Force; Copy-Item (Join-Path $env:TEMP 'node-v24.22.0-win-x64\node.exe') (Join-Path $dest 'node.exe') -Force; Remove-Item $tmp -Force; Remove-Item (Join-Path $env:TEMP 'node-v24.22.0-win-x64') -Recurse -Force"
  if errorlevel 1 (
    echo.
    echo Nao foi possivel baixar o Node.js portatil. Verifique a internet e tente novamente.
    pause
    exit /b 1
  )
)
if not exist "tools\ffmpeg\bin\ffmpeg.exe" (
  echo.
  echo Primeira inicializacao: instalando FFmpeg 6.1.1 Essentials...
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\install-ffmpeg.ps1"
  if errorlevel 1 (
    echo.
    echo Nao foi possivel preparar o FFmpeg automaticamente.
    echo Verifique a conexao com a internet e execute INICIAR.bat novamente.
    pause
    exit /b 1
  )
)
start "Auto Tube Studio" http://127.0.0.1:4320
"%~dp0tools\node-runtime\node.exe" server.mjs
pause
