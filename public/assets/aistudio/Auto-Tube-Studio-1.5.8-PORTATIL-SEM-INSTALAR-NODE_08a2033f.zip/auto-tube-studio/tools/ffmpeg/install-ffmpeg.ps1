$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$Bin = Join-Path $PSScriptRoot "bin"
$Ffmpeg = Join-Path $Bin "ffmpeg.exe"
$Ffprobe = Join-Path $Bin "ffprobe.exe"
$Version = "6.1.1"
$Url = "https://www.gyan.dev/ffmpeg/builds/packages/ffmpeg-6.1.1-essentials_build.zip"
$ExpectedSha256 = "742e32fc9f92681f9f254b925e1b613fdd8074ba40749d4879aefdb009b94cc5"

if ((Test-Path $Ffmpeg) -and (Test-Path $Ffprobe)) {
  $v = (& $Ffmpeg -version 2>&1 | Select-Object -First 1)
  if ($v -match "6\.1\.1") { Write-Host "FFmpeg $Version já está instalado em $Bin"; exit 0 }
  Write-Host "Versão local diferente encontrada; será instalada a versão $Version."
}
New-Item -ItemType Directory -Force -Path $Bin | Out-Null
$Temp = Join-Path $env:TEMP ("AutoTubeStudio-FFmpeg-" + [guid]::NewGuid().ToString("N"))
$Archive = Join-Path $Temp "ffmpeg.zip"
$Extract = Join-Path $Temp "extract"
New-Item -ItemType Directory -Force -Path $Temp,$Extract | Out-Null
try {
  Write-Host "Baixando FFmpeg $Version Essentials de gyan.dev (aprox. 80-100 MB)..."
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  Invoke-WebRequest -Uri $Url -OutFile $Archive -UseBasicParsing
  $actual = (Get-FileHash -Path $Archive -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($actual -ne $ExpectedSha256) {
    throw "SHA-256 não confere. Esperado $ExpectedSha256; recebido $actual. O arquivo foi rejeitado."
  }
  Expand-Archive -LiteralPath $Archive -DestinationPath $Extract -Force
  $exe = Get-ChildItem -Path $Extract -Filter "ffmpeg.exe" -Recurse | Select-Object -First 1
  if (-not $exe) { throw "O pacote baixado não contém ffmpeg.exe." }
  $SourceBin = $exe.Directory.FullName
  Copy-Item -Path (Join-Path $SourceBin "*") -Destination $Bin -Recurse -Force
  $v = (& $Ffmpeg -version 2>&1 | Select-Object -First 1)
  if ($LASTEXITCODE -ne 0 -or $v -notmatch "6\.1\.1") { throw "A validação do FFmpeg falhou: $v" }
  $probe = & $Ffprobe -version 2>&1 | Select-Object -First 1
  if ($LASTEXITCODE -ne 0) { throw "O ffprobe não passou na validação." }
  $license = Get-ChildItem -Path $Extract -Include "LICENSE.txt","COPYING.GPLv3","README.txt" -Recurse -File
  foreach ($f in $license) { Copy-Item $f.FullName -Destination (Join-Path $PSScriptRoot $f.Name) -Force }
  Set-Content -Path (Join-Path $PSScriptRoot "INSTALLED-VERSION.txt") -Value "$v`n$probe`nSource: $Url`nSHA256: $actual" -Encoding UTF8
  Write-Host "FFmpeg 6.1.1 e ffprobe instalados e validados."
  exit 0
}
catch {
  Write-Error $_
  exit 1
}
finally {
  Remove-Item -LiteralPath $Temp -Recurse -Force -ErrorAction SilentlyContinue
}
