# Auto Tube Studio 1.0 — Instruções para Gemini CLI

Siga `AGENTS.md` e `CLAUDE.md`. Este projeto é independente e usa a API Gemini diretamente no backend para geração de imagens. Preserve a chave em `data/settings.json`, nunca a mostre ou envie ao frontend. Produza cenas 16:9 horizontais, mantenha consistência visual e diferencie ficção, documentário e True Crime. Não invente fatos ou fontes. Consulte `docs/ARQUITETURA.md` antes de alterações técnicas.


## Modelos de página Auto Tube Studio 1.5.0
Use os IDs de página presentes em `server.mjs` (`PAGE_TYPES`) e o catálogo `app/page-models.js`. A direção visual correspondente está em `PAGE_VISUAL_GUIDES`. Preserve o modelo escolhido ao analisar roteiro e preparar prompts de imagem. Para Vidas e Cotidiano — Ficção, mantenha continuidade de personagens; para Documentário e True Crime, sinalize reconstruções ilustrativas e não invente fatos, fontes ou evidências.


## Geração de trilha original por IA — versão 1.5.5
- O estúdio pode gerar música instrumental original pela Eleven Music API usando a chave ElevenLabs configurada.
- Usar modelo music_v2_5 por padrão (music_v2 como alternativa), duração entre 1 e 10 minutos e prompt específico ao gênero, clima e narrativa do projeto.
- Preferir trilha instrumental sem voz para documentários narrados.
- Não imitar artistas, músicas existentes ou inserir letras protegidas.
- A geração é uma chamada paga/consome créditos conforme o plano. Não iniciar sem ação explícita do usuário no botão de geração.
- Antes de renderizar/publicar, o usuário deve confirmar que seu plano e os termos vigentes permitem o uso comercial/monetização. Guardar song-id, modelo, prompt, data e referência dos termos no projeto.
- Direitos variam por plano e tipo de mídia; nunca prometer ausência de Content ID ou autorização universal. Para cinema/TV/jogos e usos empresariais, verificar se é exigido Enterprise.


## Música inteligente por cena — Google Lyria 3.5
- Na análise inicial do roteiro, identificar pontos narrativos que se beneficiam de música: abertura, transições, suspense, revelações, emoção, clímax e encerramento. Não colocar trilha em todas as cenas por padrão; respeitar pausas e momentos de silêncio.
- Criar plano musical por trechos com cena/tempo, intenção emocional, estilo/instrumentos, intensidade e prompt instrumental.
- Priorizar Google Lyria 3.5 pela Gemini API configurada no estúdio, modelo `lyria-3.5`, via API Interactions (`POST https://generativelanguage.googleapis.com/v1beta/interactions`). Não usar Eleven Music para geração musical.
- Gerar faixas separadas quando houver mudanças relevantes de atmosfera; salvar MP3 em `.cache/trilha/` e registrar provedor, modelo, prompt, cenas/tempos e informações de uso em `projeto.json`.
- Claude decide necessidade e posição narrativa; a integração gera/salva o áudio; renderização aplica volume moderado, ducking sob narração e fades. Não encobrir diálogos.
- Não afirmar que é gratuito: a tabela de preços consultada indica Lyria 3.5 sem Free Tier e US$ 0,08 por música completa. Consultar sempre a tabela oficial vigente.
- Não garantir ausência de Content ID ou direitos autorais. Usuário deve conferir termos do Google e condições comerciais aplicáveis. Se a API falhar, não inventar nem baixar áudio; continuar sem trilha ou solicitar faixa licenciada.


## Auto Tube Studio 1.5.7 — Módulo Inteligente de Efeitos Sonoros
- O padrão editorial do projeto é narração limpa, sem música de fundo automática. Não gerar música por IA, não buscar/automatizar Flow Music e não inserir trilha contínua por padrão.
- Antes da montagem, analisar roteiro e cenas para identificar somente momentos em que um efeito sonoro pontual melhore a compreensão ou a emoção: transições, revelações, sinos, impactos discretos e ambientes naturais coerentes com a imagem.
- Criar plano de efeitos com `label`, `startSeconds`, `volume`, cena relacionada, intenção e fonte/licença. Evitar excesso, repetição e efeitos em cima de falas importantes.
- Usar somente efeitos com licença comercial e monetização no YouTube documentadas. O usuário precisa fornecer origem, autor, condições e URL do comprovante; nunca presumir que um efeito é livre.
- Adicionar os efeitos pelo endpoint `POST /api/projects/:id/sound-effects`, com `effects[]` contendo arquivo em base64, `mime`, `label`, `startSeconds`, `volume` (0–1) e `license` (`source`, `author`, `terms`, `proofUrl`, `commercialUse:true`, `youtubeMonetization:true`, `verifiedByUser:true`).
- Salvar arquivos em `.cache/efeitos/`; registrar metadados no projeto. Renderização mixa efeitos na posição definida, com limitador e volume moderado, preservando a inteligibilidade da narração.
- Se não houver efeito apropriado e licenciado, não inventar nem baixar sons desconhecidos; renderizar sem efeito naquela passagem.
- A música de fundo permanece opcional/manual e desativada por padrão. Recursos antigos de música permanecem no código para compatibilidade, mas não devem ser acionados automaticamente.
