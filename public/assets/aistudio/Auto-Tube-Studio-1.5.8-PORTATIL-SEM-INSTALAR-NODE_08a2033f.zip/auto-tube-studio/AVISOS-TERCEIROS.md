# Avisos de componentes e serviços de terceiros

## Dependências locais
O servidor usa módulos nativos do Node.js. O mecanismo Piper é instalado opcionalmente pelo usuário via `pip install piper-tts`; os modelos de voz ONNX são baixados separadamente. Conferir a licença individual do modelo no catálogo antes de uso comercial.

## Serviços externos
- **Google Gemini API**: geração de imagens. O usuário fornece sua própria chave em Ajustes. O uso está sujeito aos termos, limites, disponibilidade de modelos e preços definidos pelo Google: https://ai.google.dev/gemini-api/terms
- **Claude Code**: ferramenta externa opcional, instalada e autenticada separadamente pelo usuário. O Auto Tube Studio fornece arquivos de instrução e habilidades, mas não inclui nem redistribui o Claude Code: https://docs.anthropic.com/en/docs/claude-code/overview
- **Node.js**: runtime necessário para executar o servidor local: https://nodejs.org/
- **ElevenLabs API**: síntese de voz, consulta de vozes/consumo e clonagem instantânea de voz mediante autorização; sujeito a planos, permissões e cobrança: https://elevenlabs.io/docs/api-reference
- **Piper TTS**: mecanismo local opcional, instalado pelo painel; modelos de voz têm licenças próprias e devem ser verificados individualmente: https://github.com/rhasspy/piper
- **FFmpeg**: renderização e concatenação de áudio; deve ser instalado separadamente pelo usuário: https://ffmpeg.org/

## Conteúdo e direitos
A pessoa usuária é responsável por verificar direitos de uso de marcas, imagens de referência, arquivos de áudio e demais materiais que importar. Imagens geradas por IA devem ser apresentadas como ilustrações quando houver risco de serem confundidas com registros documentais.
