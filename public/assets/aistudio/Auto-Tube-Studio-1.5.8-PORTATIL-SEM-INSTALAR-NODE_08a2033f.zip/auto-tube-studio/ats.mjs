#!/usr/bin/env node
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const ROOT=path.dirname(fileURLToPath(import.meta.url));
const BASE=process.env.ATS_URL||'http://127.0.0.1:4320';
const [command,...args]=process.argv.slice(2);
const help=`Auto Tube Studio — comandos locais\n\n  node ats.mjs ajuda\n  node ats.mjs listar\n  node ats.mjs novo --tipo=vidas-ficcao --titulo="Título" [--duracao=480]\n  node ats.mjs ver <id>\n  node ats.mjs salvar-roteiro <id> <arquivo.json>\n  node ats.mjs gerar-imagem <id> <scene-id> [prompt...]\n  node ats.mjs analisar-claude <id>\n  node ats.mjs gerar-todas <id>\n  node ats.mjs adicionar-fonte <id> --titulo=... --url=https://... [--org=...] [--apoia=...]\n  node ats.mjs baixar-srt <id> [arquivo.srt]\n  node ats.mjs renderizar <id>\n  node ats.mjs diagnostico\n\nTipos: vidas-ficcao | vidas-doc | true-crime | historico | misterios\n`;
function opts(xs){const out={_:[]};for(let i=0;i<xs.length;i++){const a=xs[i];if(a.startsWith('--')){const [k,...v]=a.slice(2).split('=');out[k]=v.length?v.join('='):xs[++i];}else out._.push(a);}return out;}
async function api(route,init={}){const r=await fetch(BASE+route,{...init,headers:{'Content-Type':'application/json',...(init.headers||{})}});const d=await r.json();if(!r.ok)throw Error(d.error||`HTTP ${r.status}`);return d;}
try{
 if(!command||command==='ajuda'||command==='--help'){console.log(help);process.exit(0);}
 if(command==='listar'){const d=await api('/api/projects');console.log(JSON.stringify(d.projects,null,2));}
 else if(command==='novo'){const o=opts(args);const d=await api('/api/projects',{method:'POST',body:JSON.stringify({title:o.titulo||o.title,pageType:o.tipo||o.type,durationSeconds:Number(o.duracao)||480})});console.log(`Projeto criado: ${d.project.id}\n${d.project.title}\nTipo: ${d.project.pageType}`);}
 else if(command==='ver'){const d=await api(`/api/projects/${args[0]}`);console.log(JSON.stringify(d.project,null,2));}
 else if(command==='salvar-roteiro'){const [id,file]=args;if(!id||!file)throw Error('Informe o ID e o arquivo JSON.');const raw=JSON.parse(await fs.readFile(path.resolve(file),'utf8'));const d=await api(`/api/projects/${id}/script`,{method:'POST',body:JSON.stringify(raw)});console.log(`Roteiro salvo: ${d.sceneCount} cenas.`);}
 else if(command==='gerar-imagem'){const [id,sceneId,...prompt]=args;if(!id||!sceneId)throw Error('Informe o ID do projeto e o ID da cena.');const d=await api(`/api/projects/${id}/scenes/${sceneId}/image`,{method:'POST',body:JSON.stringify({prompt:prompt.join(' ')})});console.log(`Imagem gerada: ${d.scene.image.relativePath}`);}
 else if(command==='analisar-claude'){const id=args[0];if(!id)throw Error('Informe o ID do projeto.');const d=await api(`/api/projects/${id}/claude/analyze`,{method:'POST',body:'{}'});console.log(`Claude Code preparou ${d.sceneCount} cenas (${Math.ceil(d.totalDurationSeconds/60)} min).`);if(d.notes?.length)console.log('Observações: '+d.notes.join(' | '));}
 else if(command==='gerar-todas'){const id=args[0];if(!id)throw Error('Informe o ID do projeto.');const d=await api(`/api/projects/${id}/images/generate-all`,{method:'POST',body:JSON.stringify({onlyMissing:true})});console.log(`Imagens geradas: ${d.generated.length}`);if(d.errors.length)console.log(JSON.stringify(d.errors,null,2));}
 else if(command==='adicionar-fonte'){const id=args[0],o=opts(args.slice(1));if(!id)throw Error('Informe o ID do projeto.');const d=await api(`/api/projects/${id}/sources`,{method:'POST',body:JSON.stringify({title:o.titulo,publisher:o.org,url:o.url,supports:o.apoia})});console.log(`Fonte registrada: ${d.source.title}`);}
 else if(command==='baixar-srt'){const id=args[0],file=args[1]||`legendas-${id}.srt`;if(!id)throw Error('Informe o ID do projeto.');const r=await fetch(`${BASE}/api/projects/${id}/subtitles.srt`);if(!r.ok)throw Error((await r.json()).error||`HTTP ${r.status}`);await fs.writeFile(path.resolve(file),await r.text(),'utf8');console.log(`Legendas salvas: ${path.resolve(file)}`);}
 else if(command==='renderizar'){const id=args[0];if(!id)throw Error('Informe o ID do projeto.');const d=await api(`/api/projects/${id}/render`,{method:'POST',body:'{}'});console.log(`Vídeo renderizado: ${d.render.relativePath}`);}
 else if(command==='diagnostico'){const d=await api('/api/health');console.log(JSON.stringify(d,null,2));}
 else throw Error(`Comando desconhecido: ${command}\n${help}`);
}catch(e){console.error(`Erro: ${e.message}`);process.exitCode=1;}
