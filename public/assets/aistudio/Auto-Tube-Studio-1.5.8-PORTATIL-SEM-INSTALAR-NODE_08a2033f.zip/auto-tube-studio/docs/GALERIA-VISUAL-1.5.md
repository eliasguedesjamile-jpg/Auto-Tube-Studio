# Galeria visual 1.5.1

A galeria oferece 27 modelos: 24 estilos tradicionais identificáveis nas capturas e materiais fornecidos, mais três formatos novos.

## Galeria tradicional
História; Curiosidades; Como funciona (3D); Corpo humano e saúde; Finanças; Notícias explicadas; Mistérios; Ciência e espaço; Anúncio de interface; Bichos em 3D; Motivação e hábitos; Tecnologia; Inteligência artificial; Renda extra e negócios; Imóveis; Terror e lendas urbanas; Mitologia e folclore; Explicado em 1 minuto; Games; Quiz e desafios; Top 5 e rankings; Histórias com fundo satisfatório; Mapas e geografia; Autoridade e vendas.

## Novos formatos
- Vidas e Cotidiano — Ficção: história inventada, continuidade de personagens e direção cinematográfica.
- Vidas e Cotidiano — Documentário: povos, profissões, culturas e lugares com fatos e fontes.
- True Crime: casos criminais reais, cronologia, investigação e cuidado com vítimas e pessoas não condenadas.

## Comportamento
A escolha do modelo é armazenada como `pageType` no projeto. O backend aplica uma orientação visual própria nos prompts do Gemini. O catálogo alimenta os seletores de Novo vídeo e Série de vídeos. A galeria inclui busca textual, filtro por grupo, cartões e painel de detalhes.
