# Escrita — vídeo curto (Shorts, Reels e TikTok)

- O primeiro segundo decide: comece com gancho de até 10 palavras.
- O gancho abre uma curiosidade; não entregue a resposta imediatamente.
- Cenas de 3 a 15 palavras, uma ideia por cena.
- Inclua uma virada no meio.
- Final curto, com uma pergunta específica ou um convite para seguir; apenas um pedido.
- Como referência, use cerca de 2,6 palavras por segundo e ajuste ao ritmo da fala.
