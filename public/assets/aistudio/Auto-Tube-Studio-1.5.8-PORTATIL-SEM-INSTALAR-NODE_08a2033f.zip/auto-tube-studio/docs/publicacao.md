# Textos de publicação

Estrutura sugerida:
```json
{
  "titles": ["Melhor opção", "Opção 2", "Opção 3"],
  "description": "Descrição pronta para publicar",
  "tags": ["termo 1", "termo 2"],
  "hashtags": ["#tema1", "#tema2"],
  "socialCaption": "Legenda para redes sociais"
}
```

## Regras
- Títulos: três opções; palavra-chave no começo; curiosidade real; sem promessas que o vídeo não cumpre.
- Descrição: primeira linha com gancho e palavra-chave; resumo; capítulos quando aplicável; fontes nos documentários e True Crime; chamada para inscrição; hashtags relevantes.
- Tags: 15 a 25 termos relacionados, misturando termos amplos e específicos.
- Hashtags: 8 a 12, combinando alcance e nicho.
- Legenda social: 1 a 3 frases curtas, com gancho e pergunta ou convite.
- Não usar tags enganosas ou sem relação com o conteúdo.
