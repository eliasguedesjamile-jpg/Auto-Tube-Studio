# Formato do roteiro — Auto Tube Studio

O roteiro é um JSON com a promessa narrativa, capítulos, fontes e cenas. Exemplo:

```json
{
  "logline": "A pergunta central que o vídeo responde",
  "chapters": [
    { "title": "Abertura", "startScene": 1 },
    { "title": "O contexto", "startScene": 4 }
  ],
  "sources": [
    { "title": "Título da fonte", "publisher": "Instituição", "url": "https://...", "publishedAt": "AAAA-MM-DD", "supports": "Afirmação sustentada" }
  ],
  "scenes": [
    {
      "id": "scene-001",
      "title": "Abertura",
      "narration": "Texto falado, sem instruções de câmera.",
      "visualPrompt": "Descrição completa da imagem cinematográfica horizontal 16:9.",
      "durationSeconds": 8
    }
  ]
}
```

## Narração
- Uma ideia principal por cena.
- O texto deve soar natural quando lido em voz alta.
- Não incluir instruções técnicas, marcações de câmera ou indicação de música dentro da narração.
- A duração deve ser coerente com a quantidade de palavras e o ritmo de fala.

## Prompt visual
- Imagem em tela cheia, horizontal 16:9.
- Descrever sujeito, ambiente, época, ação, iluminação, enquadramento e atmosfera.
- Repetir os traços essenciais dos personagens recorrentes para preservar consistência.
- Não solicitar textos, legendas, logotipos, marca d'água ou elementos gráficos dentro da imagem.
- Os movimentos leves de câmera serão aplicados na edição/renderização.
- Para documentário e True Crime, descrever como ilustração/reconstrução visual quando representar fatos ou pessoas reais.

## Direção de arte dos formatos novos
- Imagens Gemini em tela cheia.
- Alguns emojis apenas em momentos pontuais e justificados.
- Marca do canal discreta no canto.
- Legenda da narração animada.
- Sem gráficos, ícones, quadros explicativos ou textos grandes na tela.
