# Escrita — vídeo longo (YouTube, 16:9)

- Nos primeiros 20 segundos, apresente o assunto e prometa o que o público vai entender. Comece pelo fato mais surpreendente ou pela pergunta central.
- Organize em 4 a 8 capítulos com títulos curtos e instigantes.
- Cada capítulo deve avançar a narrativa e preparar o próximo.
- Cenas de aproximadamente 10 a 40 palavras, uma ideia por cena.
- A cada minuto, introduza uma virada, informação nova ou pergunta relevante.
- Use frases naturais, claras e fáceis de narrar.
- Fechamento: responda à promessa da abertura, resuma a descoberta e faça um único convite à participação.
- Como referência de ritmo, use cerca de 2,4 palavras por segundo de vídeo; ajuste pela complexidade e pausas da narração.
