# Regras editoriais e de apuração

- Ficção: a história é inventada. Não apresentar acontecimentos ficcionais como fatos reais nem atribuir crimes a pessoas reais.
- Documentários e True Crime: usar fatos verificáveis. Confirmar nomes, datas, números, locais e citações em fontes confiáveis, priorizando documentos oficiais, registros públicos, estudos e fontes primárias.
- Registrar as fontes no roteiro com título, organização/autoria, URL, data de publicação quando disponível e qual afirmação sustentam.
- Caso em andamento ou controverso: atribuir alegações à fonte, apresentar versões relevantes e indicar o estágio processual correto.
- Distinguir suspeita, investigação, acusação, denúncia, julgamento, condenação, absolvição e fatos não confirmados. Não tratar suspeitos como culpados.
- Tratar vítimas e familiares com dignidade. Evitar detalhes gráficos, exploração de sofrimento e dados privados desnecessários.
- Nunca inventar citações, fontes, datas, números, falas ou provas. Se não houver confirmação, dizer que não foi possível confirmar.
- Imagens geradas por IA em conteúdos factuais são ilustrações ou reconstruções, nunca provas nem fotografias documentais autênticas.
- Não incluir instruções que facilitem violência, crime, autolesão ou fraude.
- Escrever em português brasileiro, com linguagem natural para narração.
