# Arquitetura — Auto Tube Studio 1.0

## Objetivo
Aplicação Windows local e independente para produção de vídeos narrados, usando Gemini para imagens 16:9 e Claude Code como agente opcional para pesquisa, roteiro e orquestração de tarefas.

## Stack
- Node.js 20+ com módulos nativos.
- HTTP local em `127.0.0.1:4320`.
- Interface web sem dependências npm.
- Gemini Interactions API via REST no backend.
- FFmpeg instalado pelo usuário para renderização MP4.
- Persistência JSON e arquivos locais.
- CLI `ats.mjs` e instruções Claude Code.

## Módulos
- `app/`: painel, editor de cenas, fontes, áudio, ajustes e preview.
- `server.mjs`: API, persistência, integração Gemini e pipeline FFmpeg.
- `ats.mjs`: comandos CLI usados pelo usuário e Claude Code.
- `.claude/skills/`: habilidades de ideias, pesquisa e produção de vídeo.
- `data/`: segredos e preferências locais; nunca distribuir.
- `projects/`: projetos do usuário; nunca incluir em pacotes de distribuição.

## Pipeline audiovisual
1. Roteiro com `logline`, `chapters`, `sources` e `scenes`.
2. Cada cena guarda narração, prompt visual, duração e imagem gerada.
3. Gemini gera imagem horizontal 16:9 em cada cena, usando a imagem gerada anteriormente como referência de continuidade visual quando disponível.
4. O usuário importa narração gravada ou sintetizada externamente.
5. Legendas SRT são calculadas pela duração de cada cena; ASS recebe fade-in/fade-out.
6. FFmpeg converte as imagens em 1920×1080, aplica zoompan, legendas, marca d'água e rótulo ILUSTRAÇÃO quando factual, e combina áudio.

## Limites intencionais
- Claude Code não é redistribuído nem acionado em segundo plano pelo painel; é iniciado na pasta do projeto pelo atalho `CLAUDE-CODE.bat`.
- Não há TTS próprio, sincronização palavra a palavra, thumbnails nem publicação automática na versão 1.0.
- Pesquisa e roteiro factual são conduzidos com Claude Code/ferramentas de pesquisa disponíveis; as fontes são registradas no projeto.

## Segurança
- Loopback apenas; não há exposição do servidor à rede local.
- Chave Gemini guardada em `data/settings.json`, nunca devolvida à interface.
- Arquivos de distribuição excluem `data/settings.json`, `data/watermark.png` e projetos do usuário.
- IDs, extensões e caminhos são validados antes do acesso.


## Central de narração 1.1.0
- ElevenLabs: autenticação, listagem de vozes, amostras TTS, uso de caracteres, Instant Voice Cloning mediante autorização e síntese em partes.
- Piper: execução local por Python CLI, modelos ONNX pt-BR e saída WAV.
- Windows System.Speech: enumeração e síntese de vozes locais em WAV.
