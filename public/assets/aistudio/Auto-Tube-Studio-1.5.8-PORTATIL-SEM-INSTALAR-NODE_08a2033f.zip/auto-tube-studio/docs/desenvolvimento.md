# Guia técnico — Auto Tube Studio 1.5.3

Aplicação local independente em Node.js 20+.

## Estrutura por projeto
- `project.json`: metadados e estado do projeto.
- `.cache/clipes/`: clipes temporários e arquivos de renderização.
- `.cache/midia/`: roteiro integral, roteiro estruturado, planos de produção e mídia auxiliar.
- `.cache/voz/`: narrações, arquivos de voz e partes temporárias de áudio.
- `.cache/quadros/`: imagens geradas para as cenas.
- `.cache/marca/`: marcas e recursos de identidade visual.
- `.cache/efeitos/`: efeitos sonoros e visuais.
- `.cache/trilha/`: trilhas musicais.
- `saida/`: MP4 final, capas, legendas, metadados, relatório e `publicacao.json`.

## Compatibilidade
Ao abrir um projeto legado, o servidor cria a estrutura nova e copia imagens, narrações e roteiros encontrados nos caminhos antigos para os diretórios correspondentes. Os originais são preservados para evitar perda de dados. Os leitores continuam aceitando caminhos antigos quando necessário.

## Publicação
`saida/publicacao.json` usa os campos `titulos`, `descricao`, `tags`, `hashtags` e `legendaRede`.

## Testes
Execute `npm test` e `npm start`.
