# Auto Tube Studio 1.5.8

Estúdio local e independente para criar vídeos narrados em português brasileiro, com roteiros organizados por cenas, imagens geradas diretamente pelo Gemini e renderização MP4 em 1080p. O Kiwi Studio 2.8.0 enviado pelo usuário foi usado como referência de fluxos e requisitos; o Auto Tube Studio não modifica nem depende dele.

## Requisitos do Windows
- Windows 10 ou 11 (64 bits).
- Node.js portátil: o `INICIAR.bat` baixa e prepara automaticamente uma cópia local oficial na primeira execução. Não é necessário instalar Node.js no Windows.
- FFmpeg instalado e disponível no PATH para renderização MP4: https://ffmpeg.org/download.html#build-windows
- Chave da API Gemini criada no Google AI Studio para gerar imagens: https://aistudio.google.com/app/apikey\n- Chave da API ElevenLabs para usar vozes em nuvem (opcional): https://elevenlabs.io/app/settings/api-keys
- Piper pode ser instalado pelo painel; Python é necessário para essa instalação local.
- Claude Code instalado e autenticado para usar o fluxo de produção assistido: https://docs.anthropic.com/en/docs/claude-code/overview

Depois de instalar o FFmpeg, abra um novo Prompt de Comando e confirme `ffmpeg -version`. Se o comando não for reconhecido, adicione a pasta `bin` do FFmpeg ao PATH do Windows. Também é possível definir `ATS_FFMPEG` com o caminho completo para `ffmpeg.exe`.

## Iniciar o painel
Execute `INICIAR.bat`. Na primeira execução, com internet disponível, o programa baixa o Node.js oficial e o guarda em `tools\node-runtime\`. Não altera o PATH nem instala componentes no Windows. Nas próximas inicializações, reutiliza essa cópia local. O download é necessário apenas uma vez. O painel abre em `http://127.0.0.1:4320`. O servidor fica restrito ao próprio computador.

## Claude Code — análise automática do roteiro
O Claude Code é integrado ao fluxo do painel, desde que esteja instalado e autenticado no Windows.
1. Crie o projeto e cole o roteiro completo.
2. Salve o projeto.
3. Clique em **Analisar roteiro e preparar cenas com Claude Code**.
4. O Claude Code lê o roteiro integral e os metadados do projeto, organiza capítulos, divide o texto em cenas, prepara a narração e cria prompts visuais específicos para Gemini 16:9.
5. O Auto Tube Studio valida o plano e importa as cenas para o editor. O roteiro original permanece preservado.
6. Revise as cenas e continue com geração de imagens, narração e renderização.

O Claude recebe instruções para preservar a narrativa, manter a continuidade visual e não inventar fatos ou fontes em documentários e True Crime. Pontos que exigem conferência são apresentados como observações. A análise é iniciada pelo computador local com `claude -p`; nenhuma chave API da Anthropic é solicitada no painel.

Também é possível executar `node ats.mjs analisar-claude ID_DO_PROJETO`. O atalho `CLAUDE-CODE.bat` continua disponível para abrir uma sessão interativa do Claude Code.

Exemplo de pedido ao Claude Code:

> Crie um documentário de 8 minutos sobre a expedição de Percy Fawcett. Pesquise fontes confiáveis, registre as referências, escreva o roteiro dividido em cenas, gere as imagens Gemini em 16:9 e prepare o MP4 com as legendas. Não invente fatos.

O Claude Code é um aplicativo externo e precisa estar instalado e autenticado. O Auto Tube Studio não inclui nem redistribui o Claude Code.

## Fluxo pelo painel
1. Em **Ajustes**, salve a chave Gemini, a chave API ElevenLabs, o Voice ID, o modelo de voz, o nome do canal, a marca d'água textual e, opcionalmente, o logotipo PNG transparente.
2. Crie um projeto em um dos formatos: Vidas e Cotidiano — Ficção, Vidas e Cotidiano — Documentário ou True Crime.
3. Cole o roteiro completo e clique em **Analisar roteiro e preparar cenas com Claude Code**. O Claude cria capítulos, cenas, narrações e prompts visuais. Revise e ajuste o resultado no editor. Cada cena tem narração, prompt visual e duração.
4. Em documentários e True Crime, registre as fontes consultadas na seção **Fontes do documentário**.
5. Gere as imagens individualmente ou use **Gerar imagens pendentes**. As imagens são 16:9.
6. Na **Central de narração**, escolha ElevenLabs, Piper offline ou vozes do Windows. Autentique a ElevenLabs para listar vozes, ouvir prévias e consultar o consumo. No Piper, instale o mecanismo e baixe uma voz pt-BR. Gere a narração do projeto; alternativamente, envie um áudio próprio. O texto longo é dividido em blocos e os MP3 da ElevenLabs são unidos com FFmpeg.
7. Baixe o SRT ou renderize o MP4 em 1920×1080 com movimento Ken Burns, legendas, marca d'água e identificação discreta de ilustração nos formatos factuais.

## Formatos editoriais
- `vidas-ficcao`: histórias inventadas. Não apresentar ficção como fato.
- `vidas-doc`: documentários sobre pessoas, culturas, profissões e lugares, com fontes verificáveis.
- `true-crime`: casos reais com cronologia, datas, locais, fontes e linguagem juridicamente cautelosa. Distinguir investigação, suspeita, acusação e condenação.

Nos dois formatos factuais, imagens geradas por IA são ilustrações/reconstruções, não provas nem fotografias documentais autênticas.

## Comandos CLI
Execute com o servidor iniciado:

```bash
node ats.mjs ajuda
node ats.mjs diagnostico
node ats.mjs listar
node ats.mjs novo --tipo=vidas-ficcao --titulo="Minha história" --duracao=480
node ats.mjs ver ID_DO_PROJETO
node ats.mjs salvar-roteiro ID_DO_PROJETO roteiro.json
node ats.mjs adicionar-fonte ID_DO_PROJETO --titulo="Documento" --org="Arquivo público" --url="https://..." --apoia="Data e local do acontecimento"
node ats.mjs gerar-imagem ID_DO_PROJETO scene-001
node ats.mjs analisar-claude ID_DO_PROJETO\nnode ats.mjs gerar-todas ID_DO_PROJETO
node ats.mjs baixar-srt ID_DO_PROJETO legendas.srt
node ats.mjs renderizar ID_DO_PROJETO
```

Tipos: `vidas-ficcao`, `vidas-doc`, `true-crime`, `historico`, `misterios`.

## Recursos implementados
- Aplicação local independente com painel de projetos.
- Criação, abertura e persistência de projetos.
- Editor de cenas: adicionar, editar, excluir e reordenar (a ordem da lista é a ordem do vídeo).
- Salvamento de roteiro JSON por cenas.
- Integração direta com Gemini Interactions API no backend; chave não é enviada ao navegador.\n- Central de narração com ElevenLabs (autenticação, listagem de vozes da conta, prévia por voz, consulta de consumo, seleção, clonagem instantânea por upload ou gravação do microfone e TTS em blocos), Piper offline com download de vozes pt-BR e voz de teste do Windows.
- Geração de imagens individuais e em lote, em 16:9, com a imagem anterior como referência de continuidade visual quando disponível.
- Registro de fontes com título, organização, URL e afirmação sustentada.
- Upload local de narração em áudio.
- Exportação de legendas SRT e geração de legendas ASS animadas no vídeo.
- Renderização MP4 1080p com Ken Burns, marca d'água textual ou logotipo PNG e rótulo de ilustração nos formatos factuais.
- CLI e instruções/skills para Claude Code.

## Limites conhecidos da versão 1.0
- O texto do roteiro é criado pelo usuário ou pelo Claude Code; o painel não chama Claude automaticamente em segundo plano.
- A apuração é assistida pelo Claude Code e as fontes são registradas no projeto; não há um robô de pesquisa automática próprio no painel.
- A narração é importada como arquivo de áudio; não há motor TTS integrado nesta versão.
- A sincronização das legendas usa a duração definida para cada cena, não alinhamento palavra por palavra com a voz.
- A renderização requer FFmpeg instalado no Windows.
- Não há publicação automática no YouTube nem geração automática de thumbnail nesta versão.

## Dados e privacidade
As chaves Gemini e ElevenLabs são guardadas localmente em `data/settings.json`. Não compartilhe a pasta `data/`, pois ela pode conter sua chave e seu logotipo. Os projetos e arquivos gerados ficam em `projects/`. O ZIP de distribuição não inclui configurações, chaves, logotipos privados ou projetos pessoais.


## Atualização 1.0.1 — ElevenLabs
- Campo próprio para salvar a chave API ElevenLabs em Ajustes.
- Campo para Voice ID e seleção entre Eleven Multilingual v2, Turbo v2.5 e Flash v2.5.
- Botão **Gerar narração ElevenLabs** na área de produção do projeto.
- O áudio MP3 gerado é salvo no projeto como `narracao-elevenlabs.mp3` e associado à faixa de áudio usada pelo renderizador MP4.
- O painel não recebe nem exibe a chave já salva; para substituir, basta colar uma nova chave e salvar os ajustes.
- Limite atual: até 5.000 caracteres por solicitação de narração. Roteiros maiores devem ser divididos em partes nesta versão.
- A integração usa a rota oficial Text-to-Speech da ElevenLabs. É necessário ter créditos/limites disponíveis na conta.


## Central de narração — versão 1.1.0
- **ElevenLabs:** autenticação por `/v1/user/subscription`, consulta de consumo e limites, listagem das vozes acessíveis pela API `/v2/voices`, seleção de Voice ID, prévia gerada e clonagem instantânea pela API `/v1/voices/add`. A disponibilidade da Voice Library e de clonagem depende do plano e das permissões da chave. O clone deve ser da própria voz ou de pessoa que deu autorização explícita.
- **Narração longa ElevenLabs:** o roteiro é dividido em blocos de até aproximadamente 4.500 caracteres, sintetizados separadamente e concatenados em MP3 via FFmpeg. O limite final e o consumo dependem do modelo e do plano ElevenLabs.
- **Piper:** instalação de `piper-tts` via Python, download de modelos pt-BR `cadu`, `edresson`, `faber` e `jeff`, seleção de modelo e geração local WAV. O modelo de voz requer os arquivos `.onnx` e `.onnx.json`. Consulte a licença de cada modelo antes de uso comercial.
- **Windows:** enumeração de vozes instaladas por System.Speech e geração WAV local quando disponível.
- **Privacidade:** chaves permanecem em `data/settings.json`; amostras de voz enviadas para clonagem são transmitidas à ElevenLabs. A gravação pelo microfone só inicia após ação do usuário e permissão do navegador.


## Atualização 1.2.0 — Menu completo e central de produção
- Menu lateral reorganizado com 13 etapas: Início, Aulas, Começar, Licença, Voz, Marca, Tipo de página, Vídeo teste, Novo vídeo, Série de vídeos, Meus vídeos, Música e Ajustes.
- Começar: diagnóstico do servidor/Node.js, FFmpeg, Piper, configuração Gemini/ElevenLabs e suporte WebGL do navegador.
- Aulas: guias iniciais e atalhos para os principais fluxos.
- Licença: página informativa. Esta versão não integra um servidor de licenciamento comercial e não valida chaves de compra.
- Marca: edição de nome, marca d'água textual e logotipo PNG.
- Tipo de página: seleção dos formatos Ficção, Documentário, True Crime, Documentário histórico e Mistérios e curiosidades.
- Vídeo teste: verificação das condições básicas antes de renderizar um projeto curto.
- Série de vídeos: organização local de projetos em episódios, salva no navegador.
- Meus vídeos: biblioteca dos projetos salvos pelo servidor local.
- Música: pré-escuta local de arquivo de áudio. A mixagem automática de trilha musical na exportação ainda não está implementada nesta versão.
- Central de narração: mantém os conectores ElevenLabs, Piper e voz do Windows presentes na versão anterior.


## Atualização 1.2.1 — Limite de duração
- Duração prevista no formulário Novo vídeo agora é informada em minutos, de 1 a 30.
- Limite de produção por vídeo: 30 minutos (1.800 segundos).
- O servidor limita a duração prevista do projeto e valida a soma da duração das cenas ao salvar o roteiro e antes da renderização.
- Roteiros que ultrapassarem 30 minutos são recusados com mensagem para reduzir a duração das cenas.
- A Série de vídeos informa que o limite de 30 minutos é por episódio/vídeo.


## Atualização 1.3.0 — Roteiro integral e séries autorais
- Novo vídeo: campo separado para o nome definitivo do vídeo e editor amplo para o roteiro completo.
- O roteiro completo é salvo integralmente em `projects/<id>/roteiro-completo.txt`, sem limite artificial de caracteres imposto pelo aplicativo. O envio é transmitido em fluxo para evitar montar um grande JSON na memória.
- É possível reabrir o projeto e carregar o roteiro completo para continuar editando.
- O texto integral é usado como fonte de narração pela integração ElevenLabs (com divisão automática em blocos) e pelos mecanismos locais quando não há narração por cenas.
- Série de vídeos foi redesenhada como um estúdio de planejamento: nome da série, tipo de página, duração por episódio, Bíblia da série para continuidade e um editor individual de roteiro completo para cada episódio.
- O botão Criar projetos da série cria um projeto independente por episódio, salvando o roteiro integral de cada um e a Bíblia da série nos metadados do projeto.
- A biblioteca de séries permite abrir novamente cada episódio.
- O limite de 30 minutos continua sendo aplicado ao vídeo final de cada projeto/episódio; não é um limite de caracteres do roteiro.
- Foram habilitados os tipos de página Documentário histórico e Mistérios e curiosidades na validação do servidor.


## Atualização 1.4.0 — Claude Code no fluxo de produção
- Novo botão no projeto para o Claude Code analisar o roteiro integral e estruturar o vídeo.
- O Claude Code gera capítulos, cenas sequenciais, trechos de narração, prompts visuais Gemini 16:9, durações e observações editoriais.
- O backend valida o JSON, a presença de narração e prompts e o limite máximo de 30 minutos antes de importar as cenas.
- O roteiro original continua preservado em `roteiro-completo.txt`; o plano do Claude fica arquivado em `claude-plano.json` e as cenas em `roteiro.json`.
- O CLI ganhou `node ats.mjs analisar-claude ID_DO_PROJETO`.
- O Claude Code não gera imagens nem renderiza automaticamente nesta etapa; depois da análise, use as ações de geração de imagens, narração e renderização já disponíveis no estúdio.


## Atualização 1.4.1 — FFmpeg 6.1.1 gerenciado pelo estúdio
- O primeiro `INICIAR.bat` verifica `tools/ffmpeg/bin`. Se o FFmpeg 6.1.1 não estiver instalado, chama `tools/install-ffmpeg.ps1`.
- O instalador baixa o ZIP FFmpeg 6.1.1 Essentials diretamente de Gyan.dev, confere o SHA-256 esperado, extrai `ffmpeg.exe` e `ffprobe.exe` para `tools/ffmpeg/bin` e valida a versão.
- Nas inicializações seguintes, não baixa novamente se os executáveis 6.1.1 já estiverem presentes.
- O backend prioriza o executável gerenciado pelo Auto Tube Studio; `ATS_FFMPEG`/PATH continuam como alternativas.
- A página Começar informa a versão detectada.
- O arquivo ZIP do aplicativo contém o instalador, não os binários de terceiros. A primeira instalação exige internet e baixa o pacote de FFmpeg no computador do usuário (aprox. 80–100 MB).
- Fonte: https://www.gyan.dev/ffmpeg/builds/packages/ffmpeg-6.1.1-essentials_build.zip
- A página de builds da Gyan identifica os builds estáticos como GPLv3. Consulte os avisos e a licença do pacote baixado antes de redistribuir o binário: https://www.gyan.dev/ffmpeg/builds/ e https://ffmpeg.org/legal.html


## Atualização 1.4.2 — Marca d'água personalizada
- A seção Marca agora inclui um campo próprio para carregar a marca d'água do canal em PNG transparente.
- Limite do arquivo: 2 MB.
- A prévia aparece na própria seção Marca, com fundo quadriculado para facilitar a visualização da transparência.
- A imagem é salva em `data/watermark.png` e aplicada automaticamente no canto inferior direito dos próximos vídeos renderizados pelo FFmpeg.
- O arquivo existente de marca d'água é preservado até que o usuário envie outro PNG.


## Atualização 1.5.0 — Galeria visual ampliada
- Nova galeria visual com busca, filtro por grupo, cartões de prévia e painel de detalhes.
- Modelos tradicionais recriados de forma independente a partir das categorias identificáveis nas capturas e das descrições disponíveis no pacote de referência: História, Curiosidades, Como funciona (3D), Corpo humano e saúde, Finanças, Notícias explicadas, Mistérios, Ciência e espaço, Anúncio de interface, Bichos em 3D, Motivação e hábitos, Tecnologia, Inteligência artificial, Renda extra e negócios, Imóveis, Terror e lendas urbanas, Mitologia e folclore, Explicado em 1 minuto, Games, Quiz e desafios, Top 5 e rankings, Histórias com fundo satisfatório, Mapas e geografia e Autoridade e vendas.
- Novos formatos em grupo separado: Vidas e Cotidiano — Ficção; Vidas e Cotidiano — Documentário; True Crime.
- Os 27 modelos podem ser escolhidos na galeria, em Novo vídeo e em Série de vídeos.
- O backend aceita os novos IDs e acrescenta uma direção visual específica aos prompts de geração de imagens Gemini.
- True Crime recebe instruções visuais sóbrias: sem gore, sem fabricar evidências e sem representar suspeitos como culpados sem condenação.
- Os novos formatos documentais identificam imagens como ilustrações/reconstruções, sem sugerir que sejam fotografias autênticas.
- Os cartões e direções visuais foram recriados para o Auto Tube Studio; não foram copiados arquivos executáveis, código proprietário ou imagens protegidas do Kiwitizei.
- O ZIP de referência contém o front-end e motores de renderização, mas o catálogo completo em execução é fornecido pelo executável. Assim, a galeria desta versão cobre os estilos legíveis nas capturas e os estilos descritos nos materiais inspecionados; não afirma uma extração literal do catálogo interno do executável.


## Organização dos projetos (1.5.2)
Cada projeto possui `.cache/` com subpastas `clipes`, `midia`, `voz`, `quadros`, `marca`, `efeitos` e `trilha`, além de `saida/` para os arquivos finais. O arquivo `saida/publicacao.json` segue o padrão `titulos`, `descricao`, `tags`, `hashtags` e `legendaRede`. Projetos antigos são migrados por cópia na primeira abertura; os arquivos originais permanecem preservados.

## Atualização 1.5.3 — Música de Fundo Inteligente
- A seção Música permite pré-visualizar e anexar uma trilha ao projeto ativo.
- A Biblioteca de Áudio do YouTube é indicada como fonte prioritária; o estúdio abre a biblioteca oficial, mas não baixa faixas automaticamente.
- Trilhas externas exigem registro de origem, autor, condições da licença, URL de comprovante e confirmação do usuário de que há permissão para uso comercial e monetização no YouTube. Sem esses campos, o envio é bloqueado.
- A licença é armazenada junto aos dados do projeto em `.cache/trilha` e no `project.json`.
- A renderização mixa a trilha com a narração, aplica volume configurável, ducking (redução automática da música durante a fala) e fade-in/fade-out.
- Quando o usuário informa que a licença exige crédito, o texto de atribuição é acrescentado automaticamente à descrição em `saida/publicacao.json`.
- O registro é uma declaração/documentação fornecida pelo usuário, não uma certificação jurídica nem garantia contra reivindicações Content ID. Sempre conferir a licença original e guardar seus comprovantes.


## Atualização 1.5.4 — Escolha automática de música pelo Claude Code
- Durante a montagem, o Claude Code procura automaticamente trilhas elegíveis na biblioteca local e seleciona uma de acordo com o gênero e o clima do vídeo.
- A fonte prioritária é a Biblioteca de Áudio do YouTube, mas o programa não faz download automático nem scraping dessa biblioteca. O usuário deve baixar legitimamente a faixa e adicioná-la a `data/music-library/`.
- Cada áudio precisa de um arquivo lateral `.license.json` com autorização comercial e para monetização no YouTube, confirmação do usuário, origem e comprovante.
- A faixa escolhida é copiada para o projeto, com registro em `music-selection.json`; o original da biblioteca não é movido. Créditos exigidos são acrescentados à descrição.
- Se não houver faixa aprovada, o Claude Code monta o vídeo sem música e informa o motivo. Nunca usa áudio de origem desconhecida.
- Essa documentação e confirmação reduzem riscos, mas não constituem validação jurídica nem garantia contra reivindicações Content ID.


## Atualização 1.5.5 — Geração de música original por IA
O módulo de música permite gerar trilhas originais pela Eleven Music API (modelos music_v2_5 e music_v2), usando a chave ElevenLabs já configurada. Escolha descrição, duração de 1 a 10 minutos e opção instrumental. A faixa gerada é salva em `.cache/trilha/` e integrada à mixagem do projeto. A geração consome créditos/cobrança conforme o plano. O usuário precisa confirmar que os direitos do seu plano permitem uso comercial e monetização; as permissões variam por plano e uso. Consulte https://elevenlabs.io/music-terms.


## Geração musical com Google Lyria 3.5 (1.5.6)
A geração usa a chave Gemini API configurada em Ajustes, via API Interactions e modelo `lyria-3.5`. O MP3 é salvo em `.cache/trilha/` e incorporado à renderização. **Não é gratuita na tabela de preços consultada**: Lyria 3.5 aparece sem Free Tier e a US$ 0,08 por música completa. Preços e termos podem mudar; consulte https://ai.google.dev/gemini-api/docs/pricing e https://ai.google.dev/gemini-api/terms. O sistema não garante ausência de reivindicações Content ID.


## Versão 1.5.7 — Módulo Inteligente de Efeitos Sonoros
A montagem passa a priorizar narração limpa e efeitos pontuais, sem música de fundo automática. O módulo permite importar efeitos sonoros licenciados, registrar origem/autor/termos/comprovante, definir instante de entrada e volume, e mixá-los durante a renderização. Claude Code recebe instruções para analisar roteiro e sugerir apenas efeitos úteis, evitando excesso. Música permanece opcional/manual e recursos antigos são preservados para compatibilidade.


## Versão 1.5.8 — Inicialização portátil
O Auto Tube Studio agora prepara seu próprio runtime Node.js dentro da pasta do programa. O usuário não precisa instalar Node.js nem configurar o Windows. A primeira execução requer internet para baixar o runtime oficial; depois, o programa inicia usando a cópia local.
