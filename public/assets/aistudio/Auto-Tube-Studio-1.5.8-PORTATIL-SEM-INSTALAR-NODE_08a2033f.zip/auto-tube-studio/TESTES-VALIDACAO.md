# Relatório de validação — Auto Tube Studio 1.0

Data da validação: 14/11/2026.

## Testes aprovados
- Verificação sintática de `server.mjs`, `ats.mjs` e `app/app.js` com `npm run check`.
- Análise estrutural do HTML e verificação de IDs duplicados.
- Inicialização do servidor local e resposta de `GET /api/health`.
- Detecção do FFmpeg instalado no ambiente de teste.
- Criação e leitura de projetos.
- Salvamento de roteiro com cenas e preservação de imagem já gerada ao atualizar o roteiro.
- Registro de fontes e bloqueio de URL com protocolo `javascript:`.
- Exportação de legendas SRT.
- Upload local de áudio MP3.
- Renderização repetida de MP4, incluindo substituição segura de saída existente.
- Validação do MP4 com ffprobe: H.264, 1920×1080, AAC e duração correspondente ao projeto.
- Aplicação de legendas, marca d'água e rótulo de ilustração em vídeo de teste.

## Testes não executados
- Geração real de imagem Gemini: depende de uma chave API válida do usuário e não foi simulada como se tivesse sido aprovada.
- Claude Code: depende da instalação e autenticação do aplicativo externo no computador do usuário.
- Execução em diferentes versões do Windows: o pacote foi verificado neste ambiente; a validação final no PC do usuário ainda depende da instalação dos requisitos indicados no LEIA-ME.

## Resultado
Os módulos locais de projeto, roteiro, fontes, áudio, legendas e renderização foram testados. A chamada real ao Gemini e a integração com a instalação local do Claude Code dependem das credenciais e ferramentas do usuário.


## 1.2.0 — Escopo validado
- Sintaxe JavaScript do servidor e painel verificada com `node --check`.
- Páginas do menu e interações locais adicionadas.
- Diagnóstico consulta endpoints locais reais para servidor, FFmpeg, Piper e configuração de APIs.
- A página Licença é informativa; não há serviço de ativação online.
- A página Música permite pré-escuta local, sem mixagem automática na renderização.
- Séries são organizadas no armazenamento local do navegador; não sincronizam entre computadores.
