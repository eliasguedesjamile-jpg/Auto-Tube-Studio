@echo off
cd /d "%~dp0"
where claude >nul 2>nul
if errorlevel 1 (
  echo Claude Code nao foi encontrado no PATH.
  echo Instale e autentique o Claude Code antes de executar este atalho.
  echo Documentacao: https://docs.anthropic.com/en/docs/claude-code/overview
  pause
  exit /b 1
)
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 20 ou superior e necessario para os comandos do Auto Tube Studio.
  pause
  exit /b 1
)
claude
